<?php if(!class_exists('raintpl')){exit;}?>
            <!--Start Admin Panal MAin Content Right Block-->
            <div class="main_container col-lg-9 col-md-8 col-sm-9 col-xs- pull-left">
                <div class="row main_container_head">
                    <h4><span class="glyphicon glyphicon-edit"></span>الشهادات  </h4>
                </div>

                <div class="row control_panal_body">
                    <!--Start Admin Panal Section Description-->
                    <p class="page_desc"> عرض جميع شهادات موقعك والتحكم فيها من الحقول ادناه</p>
                    <!--End Admin Panal Section Description-->

                    <div class="admin_index">
                        <!--Start Site Main Options and Data-->
                        <div class="panel panel-default  view_photo">
                            <div class="panel-heading text-right h4">عرض جميع الشهادات</div>

                            <table class="table">
                                <tr class="h4 text-center">
                                    <td class="">كود الشهادة</td>
                                    <td class="">اسم صاحب الشهادة</td>
                                    <td class="">صوره</td>
                                    <td class="">الكاتب</td>
                                    <td class="text-center">التحكم</td>
                                </tr>
                                <?php $counter1=-1; if( isset($topics) && is_array($topics) && sizeof($topics) ) foreach( $topics as $key1 => $value1 ){ $counter1++; ?>
                                <tr class="text-center">
                                    <td class="english"><?php echo $value1["mini_desc"];?></td>
                                    <td><?php echo $value1["title"];?></td>
                                    <td><img src="./template/<?php echo $value1["url"];?>" alt="<?php echo $value1["file_name"];?>"></td>
                                    <td><a href="#">د/انس محمد</a></td>
                                    <td class="text-center">
                                        <a href="delete-topic.php?topic_id=<?php echo $value1["topic_id"];?>" title="حذف" class="glyphicon glyphicon-remove"></a>
                                    </td>
                                </tr>
                                <?php } ?>
                            </table>


                            <nav class="english text-center ltr">
                                <ul class="pagination">
                                    <li>
                                        <a href="#" aria-label="Previous">
                                            <span aria-hidden="true">&laquo;</span>
                                        </a>
                                    </li>
                                    <li><a href="#">1</a></li>
                                    <li><a href="#">2</a></li>
                                    <li><a href="#">3</a></li>
                                    <li><a href="#">4</a></li>
                                    <li><a href="#">5</a></li>
                                    <li>
                                        <a href="#" aria-label="Next">
                                            <span aria-hidden="true">&raquo;</span>
                                        </a>
                                    </li>
                                </ul>
                            </nav>

                        </div>
                        <!--End Site Main Options and Data-->
                    </div>
                </div>
            </div>
            <!--Start Admin Panal MAin Content Right Block-->
        </div>
        <!--End Admin Panal Main Body-->
        <?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer-admin") . ( substr("footer-admin",-1,1) != "/" ? "/" : "" ) . basename("footer-admin") );?>