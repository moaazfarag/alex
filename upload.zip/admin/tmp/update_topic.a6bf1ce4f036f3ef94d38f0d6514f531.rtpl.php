<?php if(!class_exists('raintpl')){exit;}?>            <!--Start Admin Panal MAin Content Right Block-->
            <div class="main_container col-lg-9 col-md-8 col-sm-9 col-xs- pull-left">
                <div class="row main_container_head">
                    <h4><span class="glyphicon glyphicon-edit"></span>تعديل الموضوع    </h4>
                </div>

                <div class="row control_panal_body">
                    <!--Start Admin Panal Section Description-->
                    <p class="page_desc">تستطيع التعديل في موضوعك       من خلال المحرر ادناه</p>
                    <!--End Admin Panal Section Description-->
                    <div class="admin_index">
                        <!--Start Site Main Options and Data-->
                        <div class="panel panel-default site_info">
                            <div class="panel-heading text-right h4">تعديل الموضوع </div>

                            <form action="update-topic.php" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="topic_title">عنوان الموضوع</label>
                                    <input name="topic_title" type="text" class="form-control" id="topic_title" placeholder="عنوان الموضوع الرئيسي" value="<?php echo $title;?>">
                                </div>
                                <div class="form-group">
                                    <label for="topic_meta">نبذة مختصرة</label>
                                    <input name="topic_desc" type="text" class="form-control" id="topic_meta" placeholder=" نبذة مختصرة لا تزيد عن 255 حرف " value="<?php echo $mini_desc;?>">
                                </div>
                                <div class="form-group">
                                    <label for="topic_editor">الموضوع</label>
                                    <textarea name="topic" rows="5" class="form-control" id="topic_editor" placeholder="محتوي موضوعك"><?php echo $topic;?></textarea>
                                </div>

                                <div  class="form-group">
                                    <label>القسم</label>
                                    <select name="topic_type" class="form-control">
                                        <option value="<?php echo $type;?>"><?php echo $type;?></option>
                                        <option value="event">فعاليات و مؤتمرات</option>
                                        <option value="press"> الملف الصحفي</option>
                                        <option value="media">الملف الاعلامي</option>
                                        <option value="proud">فخر  الاكاديمية</option>
                                    </select> 
                                </div>
                                <input type="hidden" name="topic_id" value="<?php echo $topic_id;?>" />
                                <button name="update_topic" type="submit" class="btn btn-default">تعديل الموضوع</button>
                            </form>



                        </div>
                        <!--End Site Main Options and Data-->
                    </div>
                </div>
            </div>
            <!--Start Admin Panal MAin Content Right Block-->
        </div>
        <!--End Admin Panal Main Body-->


<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer-admin") . ( substr("footer-admin",-1,1) != "/" ? "/" : "" ) . basename("footer-admin") );?>