<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<!--
/*
    Author: Mohamed Hafez && Moaaz Farag
    Author URI: mohamed.hafezqo@gmail.com
    Mobile    : 00201144688896
    Version: 1.0
*/
-->

<html lang="ar">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin Panal</title>
        <link href="./template/css/bootstrap.min.css" rel="stylesheet">
        <link href="./template/css/icon.css" rel="stylesheet">
        <link rel="stylesheet" href="./template/text_editor/themes/default.min.css" type="text/css" media="all" />
        <link id="css" rel="stylesheet">
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <!--Start Header Area-->
        <header class="container-fluid navbar navbar-default">
            <div class='col-lg-4 col-md-5 col-sm-7 col-xs-12 pull-right title'>
                <span class='glyphicon glyphicon-cog title_icon'></span>
                <h1 class='h3 visible-lg-inline-block visible-md-inline-block visible-sm-inline-block visible-xs-inline-block title_text'>  لوحة تحكم موقع ديبونو </h1> 
            </div>
            <div class='col-lg-2 col-md-3 col-sm-5 col-xs-12 text-center'><div class='dropdown  dropdown_nav'>
                    <button class='btn btn-default dropdown-toggle' type='button' id='dropdownMenu1' data-toggle='dropdown'>
                        <span class='glyphicon glyphicon-user user_icon'></span>
                        Anas Mohamed
                        <span class='caret'></span>
                    </button> 
                    <ul class='dropdown-menu' role='menu' aria-labelledby='dropdownMenu1'> 
                        <li>الوان اللوحة</li> 
                        <li role='presentation'>
                            <a role='menuitem' tabindex='-1' href='#' class='light'>light</a>
                            <a role='menuitem' tabindex='-1' href='#' class='dark'>dark</a>
                        </li>
                        <li role='presentation' class='divider'></li> 
                        <li role='presentation' class='divider'></li>
                        <li role='presentation'><a role='menuitem' tabindex='-1' href='logout.php'>تسجيل خروج</a></li></ul> 
                </div></div>
        </header>
        <!--End Header Area-->

        <!--Start Mobile size Main Menu-->
        <div class="btn-group rtl btn-block hidden-lg hidden-md hidden-sm visible-xs">
            <button type="button" class="btn btn-default dropdown-toggle btn-block" data-toggle="dropdown"> <span class="glyphicon glyphicon-th-list"></span>
                القائمة الرئيسية <span class="caret"></span>
            </button>
            <ul class="dropdown-menu main_menu_xs rtl text-center" role="menu">
                <li class="text-center"><a href="index.php">الرئيسية</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="siteinfo.php">بيانات الموقع</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="#">إضافة عضو</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="#">عرض الاعضاء</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="#">إضافة فئات</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="#">عرض الفئات</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="add-topic.php">إضافة موضوع</a></li>
                <li class="divider"></li>
                <li class="text-center"><a href="view-topics.php">عرض الموضوعات</a></li>
            </ul>
        </div>
        <!--End Mobile Size Main Meni-->


        <!--Start Admin Panal Main Body-->
        <div class="container-fluid main_block">
            <!--Start Admin Panal Main Left Menu-->
            <div class="main_menu col-lg-3 col-md-4 col-sm-3 hidden-xs pull-right">
                <img src="./template/img/site_logo.png" alt="">

                <div class="panel-group">
                    <a class="main_menu_link" href="index.php"><span class="glyphicon glyphicon-home menu_link_icon"></span>الصفحة الرئيسية</a>
                </div>
                <div class="panel-group">
                    <a class="main_menu_link" href="siteinfo.php"><span class="glyphicon glyphicon-link menu_link_icon"></span>بيانات الموقع</a>
                </div>

                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#users" role="tab" aria-expanded="false" aria-controls="users">
                        <span class="glyphicon glyphicon-user menu_link_icon"></span>الاعضاء<span class="caret"></span>
                    </a>
                    <div id="users" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add_users.html">إضافة عضو</a></li>
                            <li><a href="view_users.html">عرض الاعضاء</a></li>
                        </ul>
                    </div>
                </div>


                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#addnew11" role="tab" aria-expanded="false" aria-controls="addnew11">
                        <span class="glyphicon glyphicon-edit menu_link_icon"></span>البوابة الإعلامية<span class="caret"></span>
                    </a>
                    <div id="addnew11" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add-topic.php">إضافة جديد</a></li>
                            <li><a href="view-topics.php">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>
                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#addnewcer" role="tab" aria-expanded="false" aria-controls="addnewcer">
                        <span class="glyphicon glyphicon-edit menu_link_icon"></span>ركن الشهادات<span class="caret"></span>
                    </a>
                    <div id="addnewcer" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add-cer.php">إضافة جديد</a></li>
                            <li><a href="view-cers.php">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>
                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#addnewtraining" role="tab" aria-expanded="false" aria-controls="addnewtraining">
                        <span class="glyphicon glyphicon-edit menu_link_icon"></span> الحقائب التدريبية<span class="caret"></span>
                    </a>
                    <div id="addnewtraining" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add-training-packages.php">إضافة جديد</a></li>
                            <li><a href="view-all-training.php">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>
                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#addnewcenter" role="tab" aria-expanded="false" aria-controls="addnewcenter">
                        <span class="glyphicon glyphicon-edit menu_link_icon"></span> المراكز التدريبية<span class="caret"></span>
                    </a>
                    <div id="addnewcenter" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add-training-center.php">إضافة جديد</a></li>
                            <li><a href="view-training-center.php">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>
                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#addnewvideo" role="tab" aria-expanded="false" aria-controls="addnewvideo">
                        <span class="glyphicon glyphicon-film menu_link_icon"></span> مكتبة  الفيديو  <span class="caret"></span>
                    </a>
                    <div id="addnewvideo" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add-video.php">إضافة جديد</a></li>
                            <li><a href="view-videos.php">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>

                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#image_album" role="tab" aria-expanded="false" aria-controls="image_album">
                        <span class="glyphicon glyphicon-picture menu_link_icon"></span>مكتبة الصور<span class="caret"></span>
                    </a>
                    <div id="image_album" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add-photo.php">إضافة جديد</a></li>
                            <li><a href="all-photos.php">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>

                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#slide" role="tab" aria-expanded="false" aria-controls="slide">
                        <span class="glyphicon glyphicon-film menu_link_icon"></span>السلايد شو<span class="caret"></span>
                    </a>
                    <div id="slide" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="add_photo.html">إضافة جديد</a></li>
                            <li><a href="view_photos.html">عرض الكل</a></li>
                        </ul>
                    </div>
                </div>

                <div class="panel-group" role="tablist">
                    <a class="main_menu_link" data-toggle="collapse" href="#mailist" role="tab" aria-expanded="false" aria-controls="mailist">
                        <span class="glyphicon glyphicon-envelope menu_link_icon"></span>سجل الزوار<span class="caret"></span>
                    </a>
                    <div id="mailist" class="panel-collapse collapse" role="tab" aria-expanded="false">
                        <ul class="list-group cols_item">
                            <li><a href="reviewcomments.php">عرض التعليقات</a></li>
                        </ul>
                    </div>
                </div>



            </div>
            <!--End Admin Panal Main Left Menu-->