<?php if(!class_exists('raintpl')){exit;}?>        <!--Start Footer-->
        <div class="container-fluid last-foot"></div>
        <!--End Footer-->

        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script type="text/javascript" src="./template/./js/jquery-1.9.1.js"></script>
        <script src="./template/./js/bootstrap.min.js"></script>
        <script type="text/javascript" src="./template/./js/adminy.js"></script>
        <script src="./template/./text_editor/jquery.sceditor.bbcode.min.js"></script>


        <script>
            $(document).ready(function () {
                var initEditor = function () {
                    $("textarea").sceditor({
                        plugins: 'bbcode',
                        style: "./minified/jquery.sceditor.default.min.css"
                    });
                };
                initEditor();
            });
        </script>

    </body>
</html>