<?php if(!class_exists('raintpl')){exit;}?>            <!--Start Admin Panal MAin Content Right Block-->
            <div class="main_container col-lg-9 col-md-8 col-sm-9 col-xs- pull-left">
                <div class="row main_container_head">
                    <h4><span class="glyphicon glyphicon-edit"></span>إضافة شهادة    </h4>
                </div>

                <div class="row control_panal_body">
                    <!--Start Admin Panal Section Description-->
                    <p class="page_desc">تستطيع إضافة شهادة جديدة    الى موقعك من خلال المحرر ادناه</p>
                    <!--End Admin Panal Section Description-->
                    <div class="admin_index">
                        <!--Start Site Main Options and Data-->
                        <div class="panel panel-default site_info">
                            <div class="panel-heading text-right h4">إضافة شهادة جديدة</div>

                            <form action="add-topic.php" method="post" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="topic_title">اسم  صاحب الشهادة</label>
                                    <input name="topic_title" type="text" class="form-control" id="topic_title" placeholder="اسم صاحبالشهادةي">
                                </div>
                                <div class="form-group">
                                    <label for="topic_meta">كود الشهادة</label>
                                    <input name="topic_desc" type="text" class="form-control" id="topic_meta" placeholder="     كود الشهادة   ">
                                </div>
                                <div class="form-group">
                                    <label  for="topic_img">صوره الشهادة</label>
                                    <input name="image_up" type="file" id="topic_img">
                                    <input name="topic_type" value="cer" type="hidden" id="topic_img">
                                </div>
                                <button name="add_topic" type="submit" class="btn btn-default">إضافة الشهادة</button>
                                <button type="reset" class="btn btn-default">مسح البيانات</button>
                            </form>



                        </div>
                        <!--End Site Main Options and Data-->
                    </div>
                </div>
            </div>
            <!--Start Admin Panal MAin Content Right Block-->
        </div>
        <!--End Admin Panal Main Body-->


<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer-admin") . ( substr("footer-admin",-1,1) != "/" ? "/" : "" ) . basename("footer-admin") );?>