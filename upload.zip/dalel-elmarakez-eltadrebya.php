<?php

/* 
 * Created by PhpStorm.
 * User 	: Mohamed Hafez
 * Email	: Mohamed.hafezqo@gmail.com
 * Mobile	: 01144688896
 * Date:
 * Time: 5:20 PM


 */
require_once('globals.php');

//is_admin();
//System::get('tpl')->assign('username',$_SESSION['username']);
System::Get('tpl')->draw('dalel-elmarakez-eltadrebya');


