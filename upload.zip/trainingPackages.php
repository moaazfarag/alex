<?php
/**
 * Created by PhpStorm.
 * User: Mohamed Hafez
 * Date: 10/26/2014
 * Time: 5:20 PM
 */

require_once('globals.php');

System::Get('tpl')->draw('trainingPackages');
