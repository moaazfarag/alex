version control in system 
git 

design from system design
pattern method
mvc from design patern
signal tone
active recored 


code php
snap from your code 

php versions


rdbms ->dbms for database 8 rules 
- type of relations many to one ..
read - > unlimited level of category database structure 



php info for server 
for appricated code 

study and write from interviews
software project managment methodology -> search software team 



<b>رئيس مجلس الادارة</b><br/>

عبد الناصر الشيمي<br/>

01271104720<br/>

<b>نائب رئيس مجلس الادارة</b><br/>

أسامة محمود<br/>


01122223258<br/>

<b>رئيس التحرير</b><br/>

جودة لطفي<br/>

