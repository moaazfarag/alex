<?php if(!class_exists('raintpl')){exit;}?><?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("header") . ( substr("header",-1,1) != "/" ? "/" : "" ) . basename("header") );?>
        
        <div id="main-content" class="container sidebar-left">


<div class="content">
        <div id="slider-pro-47-shortcode" class="slider-pro">
        <div class="sp-slides">
            
                <div class="sp-slide">
                    <img class="sp-image" src="./template/wp-content/uploads/2015/01/12.jpg"
                         data-src="template/wp-content/uploads/2015/01/12.jpg"
                         data-retina="wp-content/uploads/2015/01/12.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="index5643.html?p=30">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="./template/wp-content/uploads/2015/01/11.jpg"
                         data-src="template/wp-content/uploads/2015/01/11.jpg"
                         data-retina="wp-content/uploads/2015/01/11.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="indexdd23.html?p=33">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="./template/wp-content/uploads/2015/01/12.jpg"
                         data-src="template/wp-content/uploads/2015/01/12.jpg"
                         data-retina="wp-content/uploads/2015/01/12.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="index0d0b.html?p=36">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="./template/wp-content/uploads/2015/01/13.jpg"
                         data-src="template/wp-content/uploads/2015/01/13.jpg"
                         data-retina="wp-content/uploads/2015/01/13.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="indexba52.html?p=39">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="./template/wp-content/uploads/2015/01/10.jpg"
                         data-src="template/wp-content/uploads/2015/01/10.jpg"
                         data-retina="wp-content/uploads/2015/01/10.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="indexfbd5.html?p=42">أكمل القراءة &raquo;</a>
                    </div>
                </div>
                    </div>
        <div class="sp-thumbnails">
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                    </div>
    </div>

    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery('#slider-pro-47-shortcode').sliderPro({
                width: 600,
                height: 300,
                orientation: 'vertical',
                loop: false,
                arrows: true,
                buttons: false,
                thumbnailsPosition: 'left',
                thumbnailPointer: true,
                thumbnailWidth: 200,
                thumbnailHeight:72,
                breakpoints: {
                    800: {
                        thumbnailsPosition: 'bottom',
                        thumbnailWidth: 100,
                        thumbnailHeight: 50
                    },
                    500: {
                        thumbnailsPosition: 'bottom',
                        thumbnailWidth: 50,
                        thumbnailHeight: 50
                    }
                }
            });
        });
    </script>

            <div class="tertiary-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/03.jpg"/></a></div>

                <div class="tertiary-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/02.jpg"/></a></div>

                <div class="tertiary-width"><a href="membershipAndCertification.php" ><img src="./template/wp-content/uploads/2015/01/011.jpg"/></a></div>

            <div class="one_half">

        <div class=" home-widget widget-body"><h2 class="home-widget widget-header">سيرفر التسويق الالكتروني</h2>			<div class="textwidget"><p style="margin-top: 5px;">
    <a href="#">

        <img  src="./template/wp-content/uploads/2015/01/sms.jpg" />
    </a>
<p/>
<p>
    <a href="#">
        <img  src="./template/wp-content/uploads/2015/01/e-mail.jpg" />
    </a>
</p>
<p>
    <a href="#">
        <img  src="./template/wp-content/uploads/2015/01/whats.jpg" />
    </a>
</p></div>
		</div>        <div class="full-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/1-1.jpg"/></a></div>

        <style>.rpwe-block ul{
list-style: none !important;
margin-left: 0 !important;
padding-left: 0 !important;
}

.rpwe-block li{
border-bottom: 1px solid #eee;
margin-bottom: 10px;
padding-bottom: 10px;
list-style-type: none;
}

.rpwe-block a{
display: inline !important;
text-decoration: none;
}

.rpwe-block h3{
background: none !important;
clear: none;
margin-bottom: 0 !important;
margin-top: 0 !important;
font-weight: 400;
font-size: 12px !important;
line-height: 1.5em;
}

.rpwe-thumb{
border: 1px solid #eee !important;
box-shadow: none !important;
margin: 2px 10px 2px 0;
padding: 3px !important;
}

.rpwe-summary{
font-size: 12px;
}

.rpwe-time{
color: #bbb;
font-size: 11px;
}

.rpwe-alignleft{
display: inline;
float: left;
}

.rpwe-alignright{
display: inline;
float: right;
}

.rpwe-aligncenter{
display: block;
margin-left: auto;
margin-right: auto;
}

.rpwe-clearfix:before,
.rpwe-clearfix:after{
content: "";
display: table !important;
}

.rpwe-clearfix:after{
clear: both;
}

.rpwe-clearfix{
zoom: 1;
}
</style><div class=" home-widget widget-body"><h2 class="home-widget widget-header">مركز تحميل دي بونو</h2><div  class="rpwe-block "><ul class="rpwe-ul"><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index94b0.html?p=48"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="./template/wp-content/uploads/2014/12/10941698_1555959114668696_747968466_n-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index94b0.html?p=48" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index5e74.html?p=45"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="./template/wp-content/uploads/2015/01/4-3-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index5e74.html?p=45" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="indexfbd5.html?p=42"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="./template/wp-content/uploads/2015/01/10-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="indexfbd5.html?p=42" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li></ul></div><!-- Generated by http://wordpress.org/plugins/recent-posts-widget-extended/ --></div>    </div>
    <div class="one_half last">
        <div class="  home-widget widget-body"><h2 class="home-widget widget-header">خدمات اكاديمية دي بونو</h2>			<div class="textwidget"><p style="margin-top: 5px;">
    <a href="indexac94.html?cat=42">

        <img  src="./template/wp-content/uploads/2015/01/5-1.jpg" />
    </a>
<p/>
<p>
    <a href="indexffca.html?cat=41">
        <img  src="./template/wp-content/uploads/2015/01/5-2.jpg" />
    </a>
</p>
<p>
    <a href="index51fa.html?cat=40">
        <img  src="./template/wp-content/uploads/2015/01/5-3.jpg" />
    </a>
</p></div>
		</div>        <div class="full-width"><a href="indexe0a3.html?page_id=660" ><img src="./template/wp-content/uploads/2015/01/motadarbeen.jpg"/></a></div>

        <style>.rpwe-block ul{
list-style: none !important;
margin-left: 0 !important;
padding-left: 0 !important;
}

.rpwe-block li{
border-bottom: 1px solid #eee;
margin-bottom: 10px;
padding-bottom: 10px;
list-style-type: none;
}

.rpwe-block a{
display: inline !important;
text-decoration: none;
}

.rpwe-block h3{
background: none !important;
clear: none;
margin-bottom: 0 !important;
margin-top: 0 !important;
font-weight: 400;
font-size: 12px !important;
line-height: 1.5em;
}

.rpwe-thumb{
border: 1px solid #eee !important;
box-shadow: none !important;
margin: 2px 10px 2px 0;
padding: 3px !important;
}

.rpwe-summary{
font-size: 12px;
}

.rpwe-time{
color: #bbb;
font-size: 11px;
}

.rpwe-alignleft{
display: inline;
float: left;
}

.rpwe-alignright{
display: inline;
float: right;
}

.rpwe-aligncenter{
display: block;
margin-left: auto;
margin-right: auto;
}

.rpwe-clearfix:before,
.rpwe-clearfix:after{
content: "";
display: table !important;
}

.rpwe-clearfix:after{
clear: both;
}

.rpwe-clearfix{
zoom: 1;
}
</style><div class="  home-widget widget-body"><h2 class="home-widget widget-header">جديد اخبار دي بونو</h2><div  class="rpwe-block "><ul class="rpwe-ul"><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index94b0.html?p=48"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="./template/wp-content/uploads/2014/12/10941698_1555959114668696_747968466_n-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index94b0.html?p=48" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index5e74.html?p=45"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="./template/wp-content/uploads/2015/01/4-3-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index5e74.html?p=45" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="indexfbd5.html?p=42"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="./template/wp-content/uploads/2015/01/10-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="indexfbd5.html?p=42" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li></ul></div><!-- Generated by http://wordpress.org/plugins/recent-posts-widget-extended/ --></div>
    </div>
    
        <div style="margin-top: 38px; float: right;" class="last">
       
                <div class="full-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/mobile.jpg"/></a></div>

                <div class="full-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/1-2.gif"/></a></div>

                <div class="full-width"><a href="http://3agroupeg.com/en/index.html" ><img src="./template/wp-content/uploads/2015/01/234.jpg"/></a></div>

        
    </div>
    		
</div><!-- .content /-->

<aside id="sidebar">
                <div class="full-width">
                    <a href="trainingPackages.php" >
                        <img src="./template/wp-content/uploads/2015/01/05.jpg"/>
                    </a>
                </div>

                <div class="full-width"><a href="dalel-elmarakez-eltadrebya.php" ><img src="./template/wp-content/uploads/2015/01/06.jpg"/></a></div>

                <div class="full-width"><a href="members-trainers.php" ><img src="./template/wp-content/uploads/2015/01/20.jpg"/></a></div>

                <div class="full-width"><a href="int_company_credits.php" ><img src="./template/wp-content/uploads/2015/01/04.jpg"/></a></div>

                <div class="full-width"><a href="training_schedule.php" ><img src="./template/wp-content/uploads/2015/01/01.jpg"/></a></div>

                <div class="full-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/0021.jpg"/></a></div>

        <div id="youtube_responsive-2" class="widget widget_youtube_responsive"><div class="widget-top"><h4>ارشيف الفيديو</h4><div class="stripe-line"></div></div>
						<div class="widget-container"><iframe id='1' class='StefanoAI-youtube-responsive ' width='160' height='90' src='http://www.youtube.com/embed/nvtolFFXTwc?&amp;autohide=2&amp;hl=ar&amp;color=red&amp;controls=1&amp;disablekb=1&amp;fs=1&amp;iv_load_policy=3&amp;loop=0&amp;modestbranding=0&amp;rel=0&amp;theme=dark&amp;vq=default' frameborder='0' allowfullscreen="true" style=''></iframe></div></div><!-- .widget /-->        <div class="full-width"><a href="#" ><img src="./template/wp-content/uploads/2015/01/gif1.gif"/></a></div>

        <div id="newsletterwidget-2" class="widget widget_newsletterwidget"><div class="widget-top"><h4>القائمة البريدية</h4><div class="stripe-line"></div></div>
						<div class="widget-container">اشترك في القائمة البريدية ليصلك كل جديد

<script type="text/javascript">
//<![CDATA[
if (typeof newsletter_check !== "function") {
window.newsletter_check = function (f) {
    var re = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-]{1,})+\.)+([a-zA-Z0-9]{2,})+$/;
    if (!re.test(f.elements["ne"].value)) {
        alert("هذا البريد غير صالح");
        return false;
    }
    if (f.elements["nn"] && (f.elements["nn"].value == "" || f.elements["nn"].value == f.elements["nn"].defaultValue)) {
        alert("هذا الاسم غير صالح ");
        return false;
    }
    if (f.elements["ny"] && !f.elements["ny"].checked) {
        alert("You must accept the privacy statement");
        return false;
    }
    return true;
}
}
//]]>
</script>

<div class="newsletter newsletter-widget">

<script type="text/javascript">
//<![CDATA[
if (typeof newsletter_check !== "function") {
window.newsletter_check = function (f) {
    var re = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-]{1,})+\.)+([a-zA-Z0-9]{2,})+$/;
    if (!re.test(f.elements["ne"].value)) {
        alert("هذا البريد غير صالح");
        return false;
    }
    if (f.elements["nn"] && (f.elements["nn"].value == "" || f.elements["nn"].value == f.elements["nn"].defaultValue)) {
        alert("هذا الاسم غير صالح ");
        return false;
    }
    if (f.elements["ny"] && !f.elements["ny"].checked) {
        alert("You must accept the privacy statement");
        return false;
    }
    return true;
}
}
//]]>
</script>

<form action="wp-content/plugins/newsletter/do/subscribe.php" onsubmit="return newsletter_check(this)" method="post"><input type="hidden" name="nr" value="widget"/><p><input class="newsletter-firstname" type="text" name="nn" value="الاسم " onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-email" type="email" required name="ne" value="البريد الالكتروني" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-1" type="text" name="np1" value="الجوال" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-2" type="text" name="np2" value="جهة العمل" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-3" type="text" name="np3" value="الدولة" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-4" type="text" name="np4" value="المنطقة" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-5" type="text" name="np5" value="الموقع الالكتروني" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-submit" type="submit" value="اشترك"/></p></form></div></div></div><!-- .widget /--><div id="flag-counter-widget-2" class="widget flagcounter"><div class="widget-top"><h4>زوارانا</h4><div class="stripe-line"></div></div>
						<div class="widget-container"><!--flags.es Start-->
<script type="text/javascript">
 <!--//
 ami_v = 500; // no. of visitors to display, max. no.: 500.
 ami_l = "000000"; // link colour, any hexadezimal colour code.
 ami_t = "000000"; // text colour, any hexadezimal colour code.
 ami_c = "FFFFFF"; // background colour, any hexadezimal colour code.
 ami_b = "000000"; // border colour, any hexadezimal colour code.
 ami_s = 13; // font size in pixels.
 ami_w = 285; // counter width in pixels.
 ami_h = 128; // counter height in pixels.
 ami_sc = 1; // show the total visitors count, on = 1 - off = 2.
 ami_to = 30; // time in seconds, for how long an allready existing ip wont be logged again. set to 1 for an hit count.
 ami_sm = "c"; // show last Visitors or best Countries, v = visitors - c = countries.
 ami_d = "2"; // format the display in columns, no. of columns.
 //-->
</script>
<script type="text/javascript" src="./template/../www.flags.es/geoip/amiip.js"></script>
<br><a href="http://www.flags.es/" ><font size=1>flags.es</font></a>
<!--flags.es End-->
</div></div><!-- .widget /--></aside><div class="clear"></div>
<nav  class="container-last-menu">
    <div class="last-wrap">
        <div class="main-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d8%b9%d9%84%d9%89-%d8%a7%d9%84%d9%81%d9%88%d8%aa%d8%b1" class="menu"><li id="menu-item-464" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-465" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-466" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-467" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-468" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-469" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
</ul></div>    </div>
</nav><!-- .main-nav /-->
<div class="clear"></div>
</div><!-- .container /-->

<footer id="theme-footer">
	<div id="footer-widget-area" class="wide-narrow-2c">

	
	

	
		
	</div><!-- #footer-widget-area -->
	<div class="clear"></div>
</footer><!-- .Footer /-->
				
<div class="clear"></div>
<div class="footer-bottom">
    <div class="container">
        <div class="alignright">
            الموقع من تصميم وبرمجة و تطوير مجموعة ثري ايه الدولية         </div>

        <div class="alignleft">
            جميع الحقوق محفوظة لاكاديمية ديبونو العالمية        </div>
        <div class="clear"></div>
    </div><!-- .Container -->
</div><!-- .Footer bottom -->
<div id="fb-root"></div>
<link rel='stylesheet' id='example-css-css'  href='template/wp-content/plugins/slider-47/inc/examples/css/examples0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='slider-pro-css-47-css'  href='template/wp-content/plugins/slider-47/inc/dist/css/slider-pro0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='open-sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&amp;subset=latin%2Clatin-ext&amp;ver=4.1.1' type='text/css' media='all' />
<script type='text/javascript' src='template/wp-content/plugins/contact-form-7/includes/js/jquery.form.mind03d.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/debonoacademy.co\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"\u062c\u0627\u0631\u064a \u0627\u0644\u0625\u0631\u0633\u0627\u0644 ..."};
/* ]]> */
</script>
<script type='text/javascript' src='template/wp-content/plugins/contact-form-7/includes/js/scripts2f54.js?ver=4.1'></script>
<script type='text/javascript' src='template/wp-content/themes/sahifa/js/tie-scripts0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/slider-47/inc/dist/js/jquery.sliderPro.min0235.js?ver=4.1.1'></script>
<script type="text/javascript">function AI_responsive_widget() {
                        jQuery('iframe.StefanoAI-youtube-responsive').each(function() {
                            var width = jQuery(this).parent().innerWidth();
                            var maxwidth = jQuery(this).css('max-width').replace(/px/, '');
                            var pl = parseInt(jQuery(this).parent().css('padding-left').replace(/px/, ''));
                            var pr = parseInt(jQuery(this).parent().css('padding-right').replace(/px/, ''));
                            width = width - pl - pr;
                            if (maxwidth < width) {
                                width = maxwidth;
                            }
                            jQuery(this).css('width', width + "px");
                            jQuery(this).css('height', width / (16 / 9) + "px");
                        });
                    }
                    if (typeof jQuery !== 'undefined') {
                        jQuery(document).ready(function() {
                            AI_responsive_widget();
                        });
                        jQuery(window).resize(function() {
                            AI_responsive_widget();
                        });
                    }</script>
</body>

</html>