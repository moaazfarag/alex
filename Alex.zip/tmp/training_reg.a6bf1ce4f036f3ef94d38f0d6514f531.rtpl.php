<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<!--
 * Created by PhpStorm.
 * User 	: Mohamed Hafez
 * Email	: Mohamed.hafezqo@gmail.com
 * Mobile	: 01144688896
 * Date:
 * Time: 5:20 PM


-->
<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("header") . ( substr("header",-1,1) != "/" ? "/" : "" ) . basename("header") );?>
<div id="main-content" class="containersidebar-right">
<div class="content">
    
            <article class="post-612 page type-page status-publish hentry post-listing post">
                    		<div class="single-post-thumb">
					</div>
		
		
                <div class="post-inner">
                    <h1 class="name post-title endivy-title" itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing"><span itemprop="name">التسجيل في دورة</span></h1>
                    <p class="post-meta"></p>
                    <div class="clear"></div>
                    <div class="endivy">
                        
                                                <div id="ctl00_ContentPlaceHolder1_Panel1">


                            <div id="ctl00_ContentPlaceHolder1_pnlpro">

                            </div><div id="ctl00_ContentPlaceHolder1_pnlcompany">

                            </div>
                            <div>
                                <form class="basic-grey" action="" method="post">
                                    <div>
                                        <div colspan="2" class="divtitle">بيانات البرنامج</div>

                                    </div>

                                    <div>
                                        <div>الدورة:</div>
                                        <div>
                                            <select name="data[course]" required="required">
                                                
                                                    <option 
                                                    
                                                        value="528">الدورة التدريبية الاولى</option>

                                                    
                                            </select>
                                        </div>
                                    </div>


                                    <div>
                                        <div colspan="2" class="divtitle">بيانات العميل</div>

                                    </div>


                                    <div>
                                        <div>الاسم:</div>
                                        <div><input name="data[name]" required="required" type="text" i class="txtbox"/></div>
                                    </div>
                                    <div>
                                        <div>الوظيفة:</div>
                                        <div><input name="data[job]" type="text" required="required" class="txtbox"></div>
                                    </div>
                                    <div>
                                        <div>الشركة:</div>
                                        <div><input name="data[company]" type="text"  class="txtbox"></div>
                                    </div>
                                    <div>
                                        <div>العنوان-ص.ب:</div>
                                        <div><input name="data[adress]" type="text" required="required" class="txtbox"></div>
                                    </div>
                                    <div>
                                        <div>الرمز البريدي:</div>
                                        <div><input name="data[postal]" type="text" required="required" class="txtbox"></div>
                                    </div>
                                    <div>
                                        <span>الدولة:</span>
                                        <div>
                                            <input  type="text" required="required" name="data[country]" />
                                        </div>
                                    </div>
                                    <div>
                                        <div> هاتف:</div>
                                        <div><input name="data[phone]" type="text"  class="txtbox"/></div>
                                    </div>

                                    <div>
                                        <div> الموبايل:</div>
                                        <div><input name="data[mobile]" type="text"  class="txtbox"></div>
                                    </div>
                                    <div>
                                        <div> فاكس:</div>
                                        <div><input name="data[fax]" type="text" class="txtbox"></div>
                                    </div>

                                    <div>
                                        <div> البريد الالكتروني:</div>
                                        <div>
                                            <input name="data[email]" type="email"  class="txtbox">
                                        </div>
                                    </div>

                                    <div>
                                        <div>ملاحظات:</div>
                                        <div><textarea name="data[notes]" rows="2" cols="20"  class="txtbox" style="height:60px;"></textarea></div>
                                    </div>
                                    <div>
                                        <div> <input type="submit" name="ctl00$ContentPlaceHolder1$btnsave" value="تسجيل" onclick="return Validate();" id="ctl00_ContentPlaceHolder1_btnsave" class="btn"></div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                        
                                            </div><!-- .endivy /-->	
                    <span style="display:none" class="updated">2015-01-21</span>
                                            <div style="display:none" class="vcard author" itemprop="author" itemscope itemtype="http://schema.org/Person"><sdivong class="fn" itemprop="name"><a href="#?rel=author">+amin</a></sdivong></div>
                    
                </div><!-- .post-inner -->
            </article><!-- .post-listing -->
        
    
    		<div id="comments">
</div><!-- #comments -->
</div><!-- .content -->


           <!---------------------- dalel elmarakez eltadrebya  -------------->
<aside id="sidebar">
    <div id="nav_menu-7" class="widget widget_nav_menu"><div class="widget-top"><h4>الدورات التدريبية</h4><div class="stripe-line"></div></div>
	<div class="widget-container">
            <div class="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d9%84%d8%af%d9%88%d8%b1%d8%a7%d8%aa-%d8%a7%d9%84%d8%aa%d8%af%d8%b1%d9%8a%d8%a8%d9%8a%d8%a9-container">
                <ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d9%84%d8%af%d9%88%d8%b1%d8%a7%d8%aa-%d8%a7%d9%84%d8%aa%d8%af%d8%b1%d9%8a%d8%a8%d9%8a%d8%a9" class="menu">
                    <li id="menu-item-691" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-691"><a href="training_schedule.php">الدورات الحالية</a></li>
                    <li id="menu-item-689" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-689"><a href="template/wp-content/uploads/2015/01/ملف-تعريفى.pdf">حمل دليل البرامج التدريبية</a></li>
                    <li id="menu-item-695" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-695"><a href="training_reg.php">نموذج التسجيل في دورة</a></li>
                    <li id="menu-item-690" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-690"><a href="gadwal-elhkaeb.php">جدول الحقائب التدريبية</a></li>
                    <li id="menu-item-694" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-694"><a href="#">الدخول للقاعة الصوتية</a></li>
                    <li id="menu-item-692" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-692"><a href="training_request.php">طلب دورة تدريبية</a></li>
                </ul>
            </div>
        </div>
    </div><!-- .widget /-->   
    <div class="full-width">
        <a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/4331.jpg"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/gif-de-bono.gif"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/43.jpg"/></a></div>

        </aside>
<div class="clear"></div>
<nav  class="container-last-menu">
    <div class="last-wrap">
        <div class="main-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d8%b9%d9%84%d9%89-%d8%a7%d9%84%d9%81%d9%88%d8%aa%d8%b1" class="menu"><li id="menu-item-464" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-465" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-466" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-467" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-468" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-469" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
</ul></div>    </div>
</nav><!-- .main-nav /-->
<div class="clear"></div>
</div><!-- .container /-->

<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer") . ( substr("footer",-1,1) != "/" ? "/" : "" ) . basename("footer") );?>