<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<!--
 * Created by PhpStorm.
 * User 	: Mohamed Hafez
 * Email	: Mohamed.hafezqo@gmail.com
 * Mobile	: 01144688896
 * Date:
 * Time: 5:20 PM


-->

<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("header") . ( substr("header",-1,1) != "/" ? "/" : "" ) . basename("header") );?>

				
				
 <div id="main-content" class="containersidebar-right">
<style>
    .post-inner {
        padding: 0;
        height: auto;
        min-height: 0;
    }

    p.post-meta {
        padding: 0 ! important;
        margin: 0 ! important;
        border-bottom: none;
    }
</style>
<div class="content">
    
    
                            
            <article class="post-554 page type-page status-publish has-post-thumbnail hentry post-listing post">
                    		<div class="single-post-thumb">
			<img width="660" height="120" src="./template/wp-content/uploads/2015/01/signature-660x120.jpg" class="attachment-slider" alt="سجل الزوار" title="سجل الزوار" />		</div>
		
		
                <div class="post-inner">
                    <!--<h1 class="name post-title entry-title" itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing"><span itemprop="name">سجل الزوار</span></h1>-->
                    <p class="post-meta"></p>
                    <div class="clear"></div>
                    <div class="entry">
                        
                                                
                        
                                            </div><!-- .entry /-->	
                    <span style="display:none" class="updated">2015-01-21</span>
                                            <div style="display:none" class="vcard author" itemprop="author" itemscope itemtype="http://schema.org/Person"><strong class="fn" itemprop="name"><a href="#?rel=author">+amin</a></strong></div>
                    
                </div><!-- .post-inner -->
            </article><!-- .post-listing -->
            
    
    		<div id="comments">

			<h3 id="comments-title">
			تعليق واحد			</h3>

										<ol class="commentlist">	<li id="comment-7">
		<div  class="comment byuser comment-author-amin bypostauthor even thread-even depth-1 comment-wrap" >
			<div class="comment-avatar"><img alt='' src='http://0.gravatar.com/avatar/8ef3058f1cfbf8714c9ea832c0818299?s=45&amp;d=http%3A%2F%2F0.gravatar.com%2Favatar%2Fad516503a11cd5ca435acc9bb6523536%3Fs%3D45&amp;r=G' class='avatar avatar-45 photo' height='45' width='45' /></div>
			<div class="author-comment">
				<cite class="fn">amin</cite> 				<div class="comment-meta commentmetadata"><a href="?page_id=554#comment-7">	21 يناير,2015 في 12:39 ص</a></div><!-- .comment-meta .commentmetadata -->
			</div>
			<div class="clear"></div>
			<div class="comment-content">
									
				<p>محمود احمد</p>
			</div>
			<div class="reply"></div><!-- .reply -->
		</div><!-- #comment-##  -->

	</li><!-- #comment-## -->
</ol>
			    
							


		
</div><!-- #comments -->
</div><!-- .content -->

<aside id="sidebar">
        <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/gif1.gif"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/4331.jpg"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/gif-de-bono.gif"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/43.jpg"/></a></div>

        </aside><div class="clear"></div>
<nav  class="container-last-menu">
    <div class="last-wrap">
        <div class="main-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d8%b9%d9%84%d9%89-%d8%a7%d9%84%d9%81%d9%88%d8%aa%d8%b1" class="menu"><li id="menu-item-464" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-465" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-466" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-467" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-468" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-469" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
</ul></div>    </div>
</nav><!-- .main-nav /-->
<div class="clear"></div>
</div><!-- .container /-->

<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer") . ( substr("footer",-1,1) != "/" ? "/" : "" ) . basename("footer") );?>