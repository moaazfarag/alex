<?php if(!class_exists('raintpl')){exit;}?><footer id="theme-footer">
	<div id="footer-widget-area" class="wide-narrow-2c">

	
	

	
		
	</div><!-- #footer-widget-area -->
	<div class="clear"></div>
</footer>
<div class="footer-bottom" style="margin-top: 1px;">
    <div class="container">
        <div class="alignright">
            الموقع من تصميم وبرمجة و تطوير مجموعة ثري ايه الدولية         </div>

        <div class="alignleft">
            جميع الحقوق محفوظة لاكاديمية ديبونو العالمية        </div>
        <div class="clear"></div>
    </div><!-- .Container -->
</div><!-- .Footer bottom -->
<div id="fb-root"></div>
<script type='text/javascript' src='wp-content/plugins/contact-form-7/includes/js/jquery.form.mind03d.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/debonoacademy.co\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"\u062c\u0627\u0631\u064a \u0627\u0644\u0625\u0631\u0633\u0627\u0644 ..."};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/contact-form-7/includes/js/scripts2f54.js?ver=4.1'></script>
<script type='text/javascript' src='wp-content/themes/sahifa/js/tie-scripts0235.js?ver=4.1.1'></script>
<script type="text/javascript">function AI_responsive_widget() {
                        jQuery('iframe.StefanoAI-youtube-responsive').each(function() {
                            var width = jQuery(this).parent().innerWidth();
                            var maxwidth = jQuery(this).css('max-width').replace(/px/, '');
                            var pl = parseInt(jQuery(this).parent().css('padding-left').replace(/px/, ''));
                            var pr = parseInt(jQuery(this).parent().css('padding-right').replace(/px/, ''));
                            width = width - pl - pr;
                            if (maxwidth < width) {
                                width = maxwidth;
                            }
                            jQuery(this).css('width', width + "px");
                            jQuery(this).css('height', width / (16 / 9) + "px");
                        });
                    }
                    if (typeof jQuery !== 'undefined') {
                        jQuery(document).ready(function() {
                            AI_responsive_widget();
                        });
                        jQuery(window).resize(function() {
                            AI_responsive_widget();
                        });
                    }</script></body>

<!-- Mirrored from debonoacademy.co/?page_id=764 by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Mar 2015 18:33:42 GMT -->
</html>