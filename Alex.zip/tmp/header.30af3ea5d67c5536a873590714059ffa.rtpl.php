<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html dir="rtl" lang="ar" prefix="og: http://ogp.me/ns#">
    
<!-- Mirrored from debonoacademy.co/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Mar 2015 18:25:23 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="UTF-8" />
        <title>اكاديمية ديبونو | اكاديمية ديبونو العالمية</title>
        <link rel="profile" href="http://gmpg.org/xfn/11" />
        <link rel="pingback" href="./template/./xmlrpc.php/index.html" />
<link rel='stylesheet' id='custom-amin-style-css'  href='template/wp-content/themes/sahifa/css/custom0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='theme-my-login-css'  href='template/wp-content/plugins/theme-my-login/theme-my-loginfab5.css?ver=6.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='template/wp-content/plugins/contact-form-7/includes/css/styles2f54.css?ver=4.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-rtl-css'  href='template/wp-content/plugins/contact-form-7/includes/css/styles-rtl2f54.css?ver=4.1' type='text/css' media='all' />
<link rel='stylesheet' id='style2-os-css-css'  href='template/wp-content/plugins/gallery-video/style/style2-os0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='lightbox-css-css'  href='template/wp-content/plugins/gallery-video/style/lightbox0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='videogallery-all-css-css'  href='template/wp-content/plugins/gallery-video/style/videogallery-all0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-core-css-css'  href='template/wp-content/plugins/photoswipe-masonry/photoswipe-dist/photoswipe0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css'  href='template/wp-content/plugins/photoswipe-masonry/photoswipe-dist/default-skin/default-skin0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='theme-my-login-ajax-css'  href='template/wp-content/plugins/theme-my-login/modules/ajax/css/ajax0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='tie-style-css'  href='template/wp-content/themes/sahifa/style0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='Droid+Sans-css'  href='http://fonts.googleapis.com/css?family=Droid+Sans%3Aregular%2C700&amp;ver=4.1.1' type='text/css' media='all' />
<script type='text/javascript' src='template/wp-includes/js/jquery/jquery90f9.js?ver=1.11.1'></script>
<script type='text/javascript' src='template/wp-includes/js/jquery/jquery-migrate.min1576.js?ver=1.2.1'></script>
<script type='text/javascript' src='../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/gallery-video/js/video_gallery-all0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/photoswipe-masonry/photoswipe-dist/photoswipe.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/photoswipe-masonry/photoswipe-dist/photoswipe-ui-default.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/photoswipe-masonry/masonry.pkgd.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/photoswipe-masonry/imagesloaded.pkgd.min0235.js?ver=4.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpAjax = {"noPerm":"\u0644\u0627 \u062a\u0645\u0644\u0643 \u0627\u0644\u0635\u0644\u0627\u062d\u064a\u0627\u062a \u0627\u0644\u0643\u0627\u0641\u064a\u0629 \u0644\u062a\u0646\u0641\u0630 \u0647\u0630\u0627 \u0627\u0644\u0623\u0645\u0631","broken":"\u062d\u0635\u0644 \u062e\u0637\u0623 \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641"};
/* ]]> */
</script>
<script type='text/javascript' src='template/wp-includes/js/wp-ajax-response.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='template/wp-content/plugins/theme-my-login/modules/ajax/js/ajax0235.js?ver=4.1.1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="./template/./xmlrpc.php/index0db0.html?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="./template/./template/wp-includes/wlwmanifest.xml" /> 
<link rel="stylesheet" href="./template/./wp-content/themes/sahifa/rtl.css" type="text/css" media="screen" /><meta name="generator" content="WordPress 4.1.1" />
<link href="./template/./wp-content/plugins/newsletter/subscription/styles/neutral.css" type="text/css" rel="stylesheet"><link href="./template/./wp-content/plugins/newsletter/subscription/styles/widget-neutral.css" type="text/css" rel="stylesheet"><link rel="shortcut icon" href="./template/./wp-content/uploads/2015/01/favicon-3.ico" title="Favicon" />	
<!--[if IE]>
<script type="text/javascript">jQuery(document).ready(function (){ jQuery(".menu-item").has("ul").children("a").attr("aria-haspopup", "true");});</script>
<![endif]-->	
<!--[if lt IE 9]>
<script src="./template/./wp-content/themes/sahifa/js/html5.js"></script>
<script src="./template/./wp-content/themes/sahifa/js/selectivizr-min.js"></script>
<![endif]-->
<!--[if IE 9]>
<link rel="stylesheet" type="text/css" media="all" href="./template/./wp-content/themes/sahifa/css/ie9.css" />
<![endif]-->
<!--[if IE 8]>
<link rel="stylesheet" type="text/css" media="all" href="./template/./wp-content/themes/sahifa/css/ie8.css" />
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" media="all" href="./template/./wp-content/themes/sahifa/css/ie7.css" />
<![endif]-->

<meta name="viewport" content="width=1045" />
	
<style type="text/css" media="screen"> 
::-webkit-scrollbar {width: 8px; height:8px; }

body{
background-color:#0C4173 !important; 
}
	#main-nav,.cat-box-content,#sidebar .widget-container,.post-listing {border-bottom-color: #0C4173;}
	.search-block .search-button,
	#topcontrol,
	#main-nav ul li.current-menu-item a,
	#main-nav ul li.current-menu-item a:hover,
	#main-nav ul li.current-menu-parent a,
	#main-nav ul li.current-menu-parent a:hover,
	#main-nav ul li.current-page-ancestor a,
	#main-nav ul li.current-page-ancestor a:hover,
	.pagination span.current,
	.share-post span.share-text,
	.flex-control-paging li a.flex-active,
	.ei-slider-thumbs li.ei-slider-element,
	.review-percentage .review-item span span,.review-final-score ,
	.woocommerce span.onsale, .woocommerce-page span.onsale ,
	.woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle  {
		background-color:#0C4173 !important;
	}
	::-webkit-scrollbar-thumb{background-color:#0C4173 !important;}
	footer#theme-footer, .top-nav, .top-nav ul li.current-menu-item:after,#main-nav ul li.mega-menu .mega-menu-block, #main-nav ul ul {border-top-color: #0C4173;}
	.search-block:after {border-right-color:#0C4173;}
	#main-nav ul > li.parent-list:hover > a:after{border-color:transparent transparent #0C4173;}

                    .box1
            {
                border: 1px solid #f5e7bc;
                width: 570px;
                height: 144px;
                background-color:#FDF8E8;
            }
            .image1
            {
                width: 120px;
                min-height: 50px;
                margin: 10px;
                float: right;
                text-align: center;

            }
            .details1
            {
                float: right;
                width: 415px;
                //margin-top: 10px;
                margin-left: 10px;
                direction: rtl;
            }
            .title1
            {
                margin-bottom: 5px;
                font-size: 17px;
            }
            .subtitle1
            {
                margin-bottom: 5px;
            }
            .footer1
            {

                position: absolute;
                clear: both;
                color: #939393;
                font-size: 11px;
                height: 32px;
                position: relative;
                direction: rtl;
                background: #f5e7bc;
            }
            .owner1
            {
                position: absolute;
                top: 8px;
                right: 8px;
                font-size: 8pt;
            }
            .statistics1
            {
                right: auto;
                font-size: 8pt;
                left: 8px;
                float: left;
                margin-top: 8px;
                margin-left:8px;
                right: 8px;
                display: block;
            }
            .shadow1
            {
                -webkit-box-shadow: 0px 4px 16px 1px rgba(0,0,0,0.64);
                -moz-box-shadow: 0px 4px 16px 1px rgba(0,0,0,0.64);
                box-shadow: 0px 4px 16px 1px rgba(0,0,0,0.64); 
            }

</style> 

    </head>
        <body id="top" class="rtl home blog">
                    <!--<div class="background-cover"></div>-->
                        <!--<div class="header-container">-->
        <header id="theme-header" class="theme-header">
                            <div class="top-nav">
                    <div class="top-continer container">
                                                		<div class="social-icons icon_16">
		<a class="tooldown" title="Rss" href="indexd784.html?feed=rss2" ><i class="tieicon-rss"></i></a><a class="tooldown" title="Google+" href="https://plus.google.com/?gpsrc=ogpy0&amp;tab=TX" ><i class="tieicon-gplus"></i></a><a class="tooldown" title="Facebook" href="https://www.facebook.com/debono.academy00" ><i class="tieicon-facebook"></i></a><a class="tooldown" title="Twitter" href="https://twitter.com/DebonoAcademy" ><i class="tieicon-twitter"></i></a><a class="tooldown" title="LinkedIn" href="https://www.linkedin.com/profile/view?id=399434697&amp;trk=nav_responsive_tab_profile_pic" ><i class="tieicon-linkedin"></i></a><a class="tooldown" title="instagram" href="http://instagram.com/debonoacademy" ><i class="tieicon-instagram"></i></a>	</div>

                        <div class="top-menu"><ul id="menu-top" class="menu"><li id="menu-item-627" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-627"><a href="index6d0d.html?page_id=618">دخول الادارة</a></li>
</ul></div>                        <div class="search-block">
                            <form method="get" id="searchform-header" action="">
                                <button class="search-button" type="submit" value="بحث"></button> 
                                <input type="text" id="s" name="s" value="أدخل كلمة البحث ..." onfocus="if (this.value == 'أدخل كلمة البحث ...') {
                                                    this.value = '';
                                                }" onblur="if (this.value == '') {
                                                            this.value = 'أدخل كلمة البحث ...';
                                                        }"  />
                            </form>
                        </div><!-- .search-block /-->
                                                
                                            </div>
                </div><!-- .top-menu /-->
            
            <div class="header-content">
                     <div class="logo">
                        <h1>
                            <a title="اكاديمية ديبونو" href="http://localhost/debono-co/">
                                <img src="./template/./wp-content/uploads/2015/02/depono-logo6-300x90.png" alt="اكاديمية ديبونو" /><strong>اكاديمية ديبونو اكاديمية ديبونو العالمية</strong>
                            </a>
                        </h1>
                     </div><!-- .logo /-->
                                                    <nav class="header-icon-menu-nav">
                    <div class="main-menu header-icon-menu"><ul id="menu" class="menu"><li id="menu-item-546" class="vb-47 menu-item menu-item-type-custom menu-item-object-custom menu-item-546"><a href="#">الدخول للمنتديات</a></li>
<li id="menu-item-581" class="media-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-581"><a href="bawaba-advertising.php">البوابة الاعلامية</a></li>
<li id="menu-item-580" class="certi-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-580"><a href="certificates.php">ركـن  الـشهـادات</a></li>
<li id="menu-item-579" class="img-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-579"><a href="pic-lib.php">مكتبة الصور</a></li>
<li id="menu-item-578" class="video-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-578"><a href="videos.php">مكتبة الفيديو</a></li>
<li id="menu-item-577" class="mobile-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-577"><a href="phone-apps.php">تطبيق الجوال</a></li>
<li id="menu-item-556" class="visitors-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-556"><a href="visitor-feedback.php">سجـل الــــزوار</a></li>
</ul></div>                </nav><!-- .main-nav /-->

                <div class="clear"></div>
            </div>	
                                                      
                

                    </header><!-- #header /-->
        <div class="e3lan-topp container">					
			<a href="#" title="" >
				<img src="./template/./wp-content/uploads/2015/01/gif2.gif" alt="" />
			</a>
				</div>
        <!--</div>-->
        	
                <nav id="main-nav" class="container">
            <div class="container">
                <div class="main-menu">
                    <ul id="menu-main" class="menu">
                                <li id="menu-item-342" class="menu-item  menu-item-type-custom  menu-item-object-custom  current-menu-item  current_page_item  menu-item-home"><a href="index.php">الرئيسية</a></li>
                                <li id="menu-item-519" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="goals.php">الاهداف</a></li>
                                <li id="menu-item-522" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="about-us.php">عن اكاديمية ديبونو</a></li>
                                <li id="menu-item-521" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="vission.php">الرؤية</a></li>
                                <li id="menu-item-520" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="message.php">الرسالة</a></li>
                                <li id="menu-item-582" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="services.php">ركن الخدمات الالكترونية</a></li>
                                <li id="menu-item-585" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="pay.php">طرق الدفع</a></li>
                                <li id="menu-item-655" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="contact-us.php">طرق التواصل معنا</a></li>
                    </ul>
                </div>                            
            </div>
        </nav>
        <!-- .main-nav /-->