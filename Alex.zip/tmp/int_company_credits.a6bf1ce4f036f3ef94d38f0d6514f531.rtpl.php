<?php if(!class_exists('raintpl')){exit;}?><?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("header") . ( substr("header",-1,1) != "/" ? "/" : "" ) . basename("header") );?>
<div id="main-content" class="containersidebar-right">
	<div class="content">
				
		<div class="page-head">
			<h2 class="page-title">
				شبكة الاعتمادات الدولية
                         </h2>
		<div class="stripe-line"></div>
		</div>

				
                        
                        
                <!---------------------- شبكة الاعتمادات الدولي  content  -------------->

				
								
		<article class="post-572 page type-page status-publish hentry post-listing post">
					<div class="single-post-thumb">
					</div>
		
		
			<div class="post-inner">
				<h1 class="name post-title entry-title" itemprop="itemReviewed" itemscope itemtype="http://schema.org/Thing"><span itemprop="name"> الاعتمادات </span></h1>
				<p class="post-meta"></p>
				<div class="clear"></div>
				<div class="entry">
					
					
			
			<style type='text/css'>
			
				/* PhotoSwipe Plugin */
				.photoswipe_gallery {
					margin: auto;
					padding-bottom:40px;
					
					-webkit-transition: all 0.4s ease;
					-moz-transition: all 0.4s ease;
					-o-transition: all 0.4s ease;
					transition: all 0.4s ease;
	
	
					opacity:0.1;
				}
				
				.photoswipe_gallery.photoswipe_showme{
					opacity:1;
				}
				
				.photoswipe_gallery figure {
					float: left;
					
					text-align: center;
					width: 200px;
					
					padding:5px;
					margin: 0px;
					box-sizing:border-box;
				}
				.photoswipe_gallery img {
					margin:auto;
					max-width:100%;
					width: auto;					
					height: auto;
					border: 0;
				}
				.photoswipe_gallery figure figcaption{
					font-size:13px;
				}			
				
				.msnry{
					margin:auto;	
				}
			</style> <div style="clear:both"></div>	
		
		<div id="photoswipe_gallery_572_1" class="photoswipe_gallery gallery-columns-3 gallery-size-thumbnail" itemscope itemtype="http://schema.org/ImageGallery" >
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/1945802905_691d175718_b.jpg" itemprop="contentUrl" data-size="1024x759">
				        <img src=template/wp-content/uploads/2012/07/1945802905_691d175718_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/4756831209_cfe3227937_b.jpg" itemprop="contentUrl" data-size="1024x768">
				        <img src=template/wp-content/uploads/2012/07/4756831209_cfe3227937_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/4756831209_cfe3227937_b.jpg" itemprop="contentUrl" data-size="1024x768">
				        <img src=template/wp-content/uploads/2012/07/4756831209_cfe3227937_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/3844115347_1fef316b6a_b.jpg" itemprop="contentUrl" data-size="1024x653">
				        <img src=template/wp-content/uploads/2012/07/3844115347_1fef316b6a_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/3266055425_eed1ecc779_b.jpg" itemprop="contentUrl" data-size="1024x768">
				        <img src=template/wp-content/uploads/2012/07/3266055425_eed1ecc779_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/423659645_11bb162aef_o.jpg" itemprop="contentUrl" data-size="1024x683">
				        <img src=template/wp-content/uploads/2012/07/423659645_11bb162aef_o.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/5495738902_4258a1965c_b.jpg" itemprop="contentUrl" data-size="1024x683">
				        <img src=template/wp-content/uploads/2012/07/5495738902_4258a1965c_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/4088743235_690996beef_o.jpg" itemprop="contentUrl" data-size="1024x670">
				        <img src=template/wp-content/uploads/2012/07/4088743235_690996beef_o.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/7543602860_c741e700c0_b.jpg" itemprop="contentUrl" data-size="1024x598">
				        <img src=template/wp-content/uploads/2012/07/7543602860_c741e700c0_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/3461164183_544861afff_b.jpg" itemprop="contentUrl" data-size="1024x727">
				        <img src=template/wp-content/uploads/2012/07/3461164183_544861afff_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/4704140020_7122011014_b.jpg" itemprop="contentUrl" data-size="1024x670">
				        <img src=template/wp-content/uploads/2012/07/4704140020_7122011014_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/7015157331_4ff9f7772a_b.jpg" itemprop="contentUrl" data-size="1024x683">
				        <img src=template/wp-content/uploads/2012/07/7015157331_4ff9f7772a_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				
				<figure class="msnry_item" itemscope itemtype="http://schema.org/ImageObject">
					<a href="template/wp-content/uploads/2012/07/7650666944_0ca214439e_b.jpg" itemprop="contentUrl" data-size="1024x518">
				        <img src=template/wp-content/uploads/2012/07/7650666944_0ca214439e_b.jpg itemprop="thumbnail" alt=""  />
				    </a>
                                    <h4>الاعتماد </h4>
				    <figcaption class="photoswipe-gallery-caption" ></figcaption>
			    </figure>
				</div>
		
		<div style='clear:both'></div>	
		
		<script type='text/javascript'>
		
			var container_572_1 = document.querySelector('#photoswipe_gallery_572_1');
			var msnry;
			
			// initialize Masonry after all images have loaded
			imagesLoaded( container_572_1, function() {
				
				// initialize Masonry after all images have loaded
				new Masonry( container_572_1, {
				  // options...
				  itemSelector: '.msnry_item',
				  columnWidth: 200,
				  isFitWidth: true
				});
				
				(container_572_1).classList.add('photoswipe_showme');
			});
		
			// PhotoSwipe
			var initPhotoSwipeFromDOM = function(gallerySelector) {
		
		    // parse slide data (url, title, size ...) from DOM elements 
		    // (children of gallerySelector)
		    var parseThumbnailElements = function(el) {
		        var thumbElements = el.childNodes,
		            numNodes = thumbElements.length,
		            items = [],
		            figureEl,
		            linkEl,
		            size,
		            item;
		
		        for(var i = 0; i < numNodes; i++) {
		
		            figureEl = thumbElements[i]; // <figure> element
		
		            // include only element nodes 
		            if(figureEl.nodeType !== 1) {
		                continue;
		            }
		
		            linkEl = figureEl.children[0]; // <a> element
		
		            size = linkEl.getAttribute('data-size').split('x');
		
		            // create slide object
		            item = {
		                src: linkEl.getAttribute('href'),
		                w: parseInt(size[0], 10),
		                h: parseInt(size[1], 10)
		            };
		
		
		
		            if(figureEl.children.length > 1) {
		                // <figcaption> content
		                item.title = figureEl.children[1].innerHTML; 
		            }
		
		            if(linkEl.children.length > 0) {
		                // <img> thumbnail element, retrieving thumbnail url
		                item.msrc = linkEl.children[0].getAttribute('src');
		            } 
		
		            item.el = figureEl; // save link to element for getThumbBoundsFn
		            items.push(item);
		        }
		
		        return items;
		    };
		
		    // find nearest parent element
		    var closest = function closest(el, fn) {
		        return el && ( fn(el) ? el : closest(el.parentNode, fn) );
		    };
		
		    // triggers when user clicks on thumbnail
		    var onThumbnailsClick = function(e) {
		        e = e || window.event;
		        e.preventDefault ? e.preventDefault() : e.returnValue = false;
		
		        var eTarget = e.target || e.srcElement;
		
		        // find root element of slide
		        var clickedListItem = closest(eTarget, function(el) {
		            return el.tagName === 'FIGURE';
		        });
		
		        if(!clickedListItem) {
		            return;
		        }
		
		        // find index of clicked item by looping through all child nodes
		        // alternatively, you may define index via data- attribute
		        var clickedGallery = clickedListItem.parentNode,
		            childNodes = clickedListItem.parentNode.childNodes,
		            numChildNodes = childNodes.length,
		            nodeIndex = 0,
		            index;
		
		        for (var i = 0; i < numChildNodes; i++) {
		            if(childNodes[i].nodeType !== 1) { 
		                continue; 
		            }
		
		            if(childNodes[i] === clickedListItem) {
		                index = nodeIndex;
		                break;
		            }
		            nodeIndex++;
		        }
		
		
		
		        if(index >= 0) {
		            // open PhotoSwipe if valid index found
		            openPhotoSwipe( index, clickedGallery );
		        }
		        return false;
		    };
		
		    // parse picture index and gallery index from URL (#&pid=1&gid=2)
		    var photoswipeParseHash = function() {
		        var hash = window.location.hash.substring(1),
		        params = {};
		
		        if(hash.length < 5) {
		            return params;
		        }
		
		        var vars = hash.split('&');
		        for (var i = 0; i < vars.length; i++) {
		            if(!vars[i]) {
		                continue;
		            }
		            var pair = vars[i].split('=');  
		            if(pair.length < 2) {
		                continue;
		            }           
		            params[pair[0]] = pair[1];
		        }
		
		        if(params.gid) {
		            params.gid = parseInt(params.gid, 10);
		        }
		
		        if(!params.hasOwnProperty('pid')) {
		            return params;
		        }
		        params.pid = parseInt(params.pid, 10);
		        return params;
		    };
		
		    var openPhotoSwipe = function(index, galleryElement, disableAnimation) {
		        var pswpElement = document.querySelectorAll('.pswp')[0],
		            gallery,
		            options,
		            items;
		
		        items = parseThumbnailElements(galleryElement);
		
		        // define options (if needed)
		        options = {
		            index: index,
		
		            // define gallery index (for URL)
		            galleryUID: galleryElement.getAttribute('data-pswp-uid'),
		
		            getThumbBoundsFn: function(index) {
		                // See Options -> getThumbBoundsFn section of documentation for more info
		                var thumbnail = items[index].el.getElementsByTagName('img')[0], // find thumbnail
		                    pageYScroll = window.pageYOffset || document.documentElement.scrollTop,
		                    rect = thumbnail.getBoundingClientRect(); 
		
		                return {x:rect.left, y:rect.top + pageYScroll, w:rect.width};
		            }
		
		        };
		
		        if(disableAnimation) {
		            options.showAnimationDuration = 0;
		        }
		
		        // Pass data to PhotoSwipe and initialize it
		        gallery = new PhotoSwipe( pswpElement, PhotoSwipeUI_Default, items, options);
		        gallery.init();
		    };
		
		    // loop through all gallery elements and bind events
		    var galleryElements = document.querySelectorAll( gallerySelector );
		
		    for(var i = 0, l = galleryElements.length; i < l; i++) {
		        galleryElements[i].setAttribute('data-pswp-uid', i+1);
		        galleryElements[i].onclick = onThumbnailsClick;
		    }
		
		    // Parse URL and open gallery if it contains #&pid=3&gid=1
		    var hashData = photoswipeParseHash();
		    if(hashData.pid > 0 && hashData.gid > 0) {
		        openPhotoSwipe( hashData.pid - 1 ,  galleryElements[ hashData.gid - 1 ], true );
		    }
		};
		
		// execute above function
		initPhotoSwipeFromDOM('.photoswipe_gallery');
	
	</script>
	
	
		
			
			<!-- Root element of PhotoSwipe. Must have class pswp. -->
			<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
			
			    <!-- Background of PhotoSwipe. 
			         Its a separate element, as animating opacity is faster than rgba(). -->
			    <div class="pswp__bg"></div>
			
			    <!-- Slides wrapper with overflow:hidden. -->
			    <div class="pswp__scroll-wrap">
			
			        <!-- Container that holds slides. 
			                PhotoSwipe keeps only 3 slides in DOM to save memory. -->
			        <div class="pswp__container">
			            <!-- dont modify these 3 pswp__item elements, data is added later on -->
			            <div class="pswp__item"></div>
			            <div class="pswp__item"></div>
			            <div class="pswp__item"></div>
			        </div>
			
			        <!-- Default (PhotoSwipeUI_Default) interface on top of sliding area. Can be changed. -->
			        <div class="pswp__ui pswp__ui--hidden">
			
			            <div class="pswp__top-bar">
			
			                <!--  Controls are self-explanatory. Order can be changed. -->
			
			                <div class="pswp__counter"></div>
			
			                <button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
			
			                <button class="pswp__button pswp__button--share" title="Share"></button>
			
			                <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button>
			
			                <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
			
			                <!-- Preloader demo http://codepen.io/dimsemenov/pen/yyBWoR -->
			                <!-- element will get class pswp__preloader--active when preloader is running -->
			                <div class="pswp__preloader">
			                    <div class="pswp__preloader__icn">
			                      <div class="pswp__preloader__cut">
			                        <div class="pswp__preloader__donut"></div>
			                      </div>
			                    </div>
			                </div>
			            </div>
			
			            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
			                <div class="pswp__share-tooltip"></div> 
			            </div>
			
			            <button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)">
			            </button>
			
			            <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)">
			            </button>
			
			            <div class="pswp__caption">
			                <div class="pswp__caption__center"></div>
			            </div>
			
			          </div>
			
			        </div>
			
			</div>
			
										
					
									</div><!-- .entry /-->	
				<span style="display:none" class="updated">2015-01-21</span>
								<div style="display:none" class="vcard author" itemprop="author" itemscope itemtype="http://schema.org/Person"><strong class="fn" itemprop="name"><a href="#?rel=author">+amin</a></strong></div>
								
			</div><!-- .post-inner -->
		</article><!-- .post-listing -->
				
				
				<div id="comments">

		

		


                </div> <br/><br/>
           <!---------------------- شبكة الاعتمادات الدولي  content -------------->

            
		</div>
<aside id="sidebar">
    <div id="nav_menu-8" class="widget widget_nav_menu"><div class="widget-top"><h4>المراكز التدريبية</h4><div class="stripe-line"></div></div>
						<div class="widget-container">
                                                    <div class="menu-%d8%a7%d9%84%d9%85%d8%b1%d8%a7%d9%83%d8%b2-%d8%a7%d9%84%d8%aa%d8%af%d8%b1%d9%8a%d8%a8%d9%8a%d8%a9-container">
                                                        <ul id="menu-%d8%a7%d9%84%d9%85%d8%b1%d8%a7%d9%83%d8%b2-%d8%a7%d9%84%d8%aa%d8%af%d8%b1%d9%8a%d8%a8%d9%8a%d8%a9" class="menu">
                                                            <li id="menu-item-673" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-673">
                                                                <a href="int_company_credits.php">اعتمادات دولية</a></li>
                                                            <li id="menu-item-674" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-674">
                                                                <a href="local_company_credits.php">اعتمادات محلية</a></li>
</ul></div></div></div><!-- .widget /-->        <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/4331.jpg"></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/gif-de-bono.gif"></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/43.jpg"></a></div>

        </aside>
<div class="clear"></div>
<nav class="container-last-menu">
    <div class="last-wrap">
        <div class="main-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d8%b9%d9%84%d9%89-%d8%a7%d9%84%d9%81%d9%88%d8%aa%d8%b1" class="menu"><li id="menu-item-464" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-465" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-466" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-467" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-468" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-469" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
</ul></div>    </div>
</nav><!-- .main-nav /-->
<div class="clear"></div>
</div>

<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer") . ( substr("footer",-1,1) != "/" ? "/" : "" ) . basename("footer") );?>