<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<!--
 * Created by PhpStorm.
 * User 	: Mohamed Hafez
 * Email	: Mohamed.hafezqo@gmail.com
 * Mobile	: 01144688896
 * Date:
 * Time: 5:20 PM


-->
<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("header") . ( substr("header",-1,1) != "/" ? "/" : "" ) . basename("header") );?>

<div id="main-content" class="containersidebar-right">
	<div class="content">
				
				
								
		<article class="post-715 page type-page status-publish hentry post-listing post">
					<div class="single-post-thumb">
					</div>
		
		
			<div class="post-inner">
				<h1 class="name post-title entry-title" itemprop="itemReviewed" itemscope="" itemtype="http://schema.org/Thing"><span itemprop="name">عضوية متدرب</span></h1>
				<p class="post-meta"></p>
				<div class="clear"></div>
				<div class="entry">
					
					<div id="flexicontent" class="flexicontent item627 type1">
<div class="description">
<div class="desc-content">
<p><strong>•&nbsp;شروط العضوية..</strong><br>
<strong>يجب أن تتوفر في عضو الجمعية الشروط التالية:</strong><br>
<strong>1-&nbsp;أن يكون سعودي الجنسية.<br>
2-&nbsp;أن يكون قد أتم الثامنة عشرة من عمره (عدا عضوية الطالب).<br>
3-&nbsp;أن يكون كامل الأهلية المعتبرة شرعا.<br>
4-&nbsp;أن يكون غير محكوم عليه بإدانة في جريمة مخلة بالشرف أو الأمانة ما لم يكن قد رد إليه اعتباره.<br>
5-&nbsp;أن يكون قد سدد الحد الأدنى للاشتراك السنوي.</strong></p>
<p><strong>•&nbsp;فقدان العضوية..<br>
</strong></p>
<p><strong>يتم فقدان العضوية في الحالات التالية:</strong><br>
<strong>1-&nbsp;الوفاة.<br>
2-&nbsp;الانسحاب من الجمعية بطلب كتابي.<br>
3-&nbsp;إذا فقد شرطا من شروط العضوية الواردة بالمادة (4).<br>
4-&nbsp;إذا ألحق بالجمعية أضرارا سواء كانت مادية أو معنوية عن عمد، ويعود تقدير ذلك لمجلس الإدارة.<br>
5-&nbsp;إذا تأخر عن تسديد الاشتراك لمدة ستة أشهر من بداية السنة المالية للجمعية بعد إخطاره بخطاب على عنوانه المدون لديها وفيما عدا الحالتين (1، 2) يصدر بفقدان العضوية قرار من مجلس الإدارة.</strong></p>
<p><strong>•&nbsp;إعادة العضوية لمن فقدها..</strong><br>
<strong>يجوز لمجلس الإدارة إعادة العضوية لمن فقدها بسبب عدم تسديده للاشتراك السنوي في حال أدائه المبلغ المستحق عليه، ولا يجوز للعضو أو لو رثته أو لمن فقد عضويته استرداد ما تم دفعه للجمعية من اشتراكات أو تبرعات أو هبات سواء كان ذلك نقديا أو عينيا ومهما كانت الأسباب.</strong></p>
<p><strong>&nbsp;</strong></p>
</div>
</div>
<div class="clear">&nbsp;<a title="تسجيل" href="register/index.html"><img class=" size-full wp-image-723 aligncenter" src="./template/wp-content/uploads/2015/01/7-2.jpg" alt="7 (2)" width="660" height="120"></a></div>
</div>
<div class="clear"></div>
										
					
									</div><!-- .entry /-->	
				<span style="display:none" class="updated">2015-01-25</span>
								<div style="display:none" class="vcard author" itemprop="author" itemscope="" itemtype="http://schema.org/Person"><strong class="fn" itemprop="name"><a href="#?rel=author">+amin</a></strong></div>
								
			</div><!-- .post-inner -->
		</article><!-- .post-listing -->
				
				
				<div id="comments">
	

		
</div><!-- #comments -->
	</div><!-- .content -->

<aside id="sidebar">
<div id="nav_menu-6" class="widget widget_nav_menu">
    <div class="widget-top">
        <h4>العضوية و الاعتمادات</h4>
        <div class="stripe-line"></div>
            
    </div>
	
    <div class="widget-container">
        <div class="menu-container">
            <ul id="menu" class="menu">
                <li id="menu-item-721" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-701 current_page_item menu-item-721">
                         <a href="#">نظام العضوية و الاعتمادات</a></li>
                <li id="menu-item-718" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-718">
                        <a href="traineeMembership.php">عضوية متدرب</a></li>
                <li id="menu-item-719" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-719">
                    <a href="#">عضوية مدرب</a></li>
                <li id="menu-item-720" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-720">
                    <a href="#">عضوية مركز تدريب</a></li>
                <li id="menu-item-709" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-709">
                    <a href="#">التاكد من رقم العضوية</a></li>
            </ul></div>
    </div>
</div><!-- .widget /-->        <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/gif1.gif"></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/4331.jpg"></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/gif-de-bono.gif"></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="./template/wp-content/uploads/2015/01/43.jpg"></a></div>

        </aside><div class="clear"></div>
<nav class="container-last-menu">
    <div class="last-wrap">
        <div class="main-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d8%b9%d9%84%d9%89-%d8%a7%d9%84%d9%81%d9%88%d8%aa%d8%b1" class="menu"><li id="menu-item-464" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-465" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-466" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-467" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-468" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-469" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
</ul></div>    </div>
</nav><!-- .main-nav /-->
<div class="clear"></div>
</div>
<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer") . ( substr("footer",-1,1) != "/" ? "/" : "" ) . basename("footer") );?>
