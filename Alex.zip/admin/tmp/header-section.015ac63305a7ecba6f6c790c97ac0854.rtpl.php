<?php if(!class_exists('raintpl')){exit;}?>
<!--header end-->
<!--sidebar start-->
<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active" href="index.php">
                    <i class="icon-dashboard"></i>
                    <span>Home</span>
                </a>
            </li>
            
            
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="icon-laptop"></i>
                    <span>Visits Message</span>
                </a>
                <ul class="sub">
                    <li><a  href="vrmessage-admin.php">Visit Request Message</a></li>
                    <li><a  href="#">Handled Message</a></li>
                    <li><a  href="addOneVisit.php">Add one visit</a></li>
                    <li><a  href="upload.php">Upload Visits</a></li>
                </ul>
            </li>
            
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="icon-user"></i>
                    <span>Users</span>
                </a>
                <ul class="sub">
                    <li><a  href="users.php">All users</a></li>
                    <li><a  href="addUser.php">Add users</a></li>
                </ul>
            </li>
            
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->





