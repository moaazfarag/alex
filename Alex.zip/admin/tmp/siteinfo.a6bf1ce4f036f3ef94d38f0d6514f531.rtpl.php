<?php if(!class_exists('raintpl')){exit;}?>

            <!--Start Admin Panal MAin Content Right Block-->
            <div class="main_container col-lg-9 col-md-8 col-sm-9 col-xs- pull-left">
                <div class="row main_container_head">
                    <h4><span class="glyphicon glyphicon-link"></span>بيانات الموقع </h4>
                </div>

                <div class="row control_panal_body">
                    <!--Start Admin Panal Section Description-->
                    <p class="page_desc">تمكنك صفحة بيانات الموقع من تعديل اعدادات وبيانات موقعك الالكتروني. كن حريص في تعديل بيانات هذه الصفحة لان هذه التعديلات ستطبق مباشره علي موقعك الالكتروني...</p>
                    <!--End Admin Panal Section Description-->





                    <div class="admin_index">
                        <!--Start Site Main Options and Data-->
                        <div class="panel panel-default site_info">
                            <div class="panel-heading text-right h4">بيانات الموقع</div>

                            <form action="update-site-info.php" method="post">
                                <?php $counter1=-1; if( isset($info) && is_array($info) && sizeof($info) ) foreach( $info as $key1 => $value1 ){ $counter1++; ?>
                                <div class="form-group">
                                    <label for="site_title"><?php echo $value1["name"];?></label>
                                    <input value="<?php echo $value1["title"];?>" name="<?php echo $value1["id"];?>" type="text" class="form-control" id="site_title" placeholder="عنوان اهداف الموقع ">
                                </div>
                                <div class="form-group">
                                    <label for="topic_editor">الوصف</label>
                                    <textarea value="" name="<?php echo $value1["textarea_name"];?>"  rows="5" class="form-control">
<?php echo $value1["description"];?>
                                    </textarea>
                                </div>
                                     <?php } ?>



                                <button name="update" type="submit" class="btn btn-default">حفط البيانات</button>
                            </form>



                        </div>
                        <!--End Site Main Options and Data-->
                    </div>
                </div>
            </div>
            <!--Start Admin Panal MAin Content Right Block-->
        </div>
        <!--End Admin Panal Main Body-->


<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer-admin") . ( substr("footer-admin",-1,1) != "/" ? "/" : "" ) . basename("footer-admin") );?>