<?php if(!class_exists('raintpl')){exit;}?><!DOCTYPE html>
<html dir="rtl" lang="ar" prefix="og: http://ogp.me/ns#">
    
<!-- Mirrored from debonoacademy.co/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Mar 2015 18:25:23 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
        <meta charset="UTF-8" />
        <title>اكاديمية ديبونو | اكاديمية ديبونو العالمية</title>
        <link rel="profile" href="http://gmpg.org/xfn/11" />
        <link rel="pingback" href="../template/xmlrpc.php/index.html" />

        <link rel="alternate" type="application/rss+xml" title="اكاديمية ديبونو &raquo; الخلاصة" href="../template/indexd784.html?feed=rss2" />
<link rel="alternate" type="application/rss+xml" title="اكاديمية ديبونو &raquo; خلاصة التعليقات" href="../template/indexa6da.html?feed=comments-rss2" />
<link rel='stylesheet' id='custom-amin-style-css'  href='wp-content/themes/sahifa/css/custom0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='theme-my-login-css'  href='wp-content/plugins/theme-my-login/theme-my-loginfab5.css?ver=6.3.8' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='wp-content/plugins/contact-form-7/includes/css/styles2f54.css?ver=4.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-rtl-css'  href='wp-content/plugins/contact-form-7/includes/css/styles-rtl2f54.css?ver=4.1' type='text/css' media='all' />
<link rel='stylesheet' id='style2-os-css-css'  href='wp-content/plugins/gallery-video/style/style2-os0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='lightbox-css-css'  href='wp-content/plugins/gallery-video/style/lightbox0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='videogallery-all-css-css'  href='wp-content/plugins/gallery-video/style/videogallery-all0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-core-css-css'  href='wp-content/plugins/photoswipe-masonry/photoswipe-dist/photoswipe0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='photoswipe-default-skin-css'  href='wp-content/plugins/photoswipe-masonry/photoswipe-dist/default-skin/default-skin0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='theme-my-login-ajax-css'  href='wp-content/plugins/theme-my-login/modules/ajax/css/ajax0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='tie-style-css'  href='wp-content/themes/sahifa/style0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='Droid+Sans-css'  href='http://fonts.googleapis.com/css?family=Droid+Sans%3Aregular%2C700&amp;ver=4.1.1' type='text/css' media='all' />
<script type='text/javascript' src='wp-includes/js/jquery/jquery90f9.js?ver=1.11.1'></script>
<script type='text/javascript' src='wp-includes/js/jquery/jquery-migrate.min1576.js?ver=1.2.1'></script>
<script type='text/javascript' src='../ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/gallery-video/js/video_gallery-all0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/photoswipe-masonry/photoswipe-dist/photoswipe.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/photoswipe-masonry/photoswipe-dist/photoswipe-ui-default.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/photoswipe-masonry/masonry.pkgd.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/photoswipe-masonry/imagesloaded.pkgd.min0235.js?ver=4.1.1'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wpAjax = {"noPerm":"\u0644\u0627 \u062a\u0645\u0644\u0643 \u0627\u0644\u0635\u0644\u0627\u062d\u064a\u0627\u062a \u0627\u0644\u0643\u0627\u0641\u064a\u0629 \u0644\u062a\u0646\u0641\u0630 \u0647\u0630\u0627 \u0627\u0644\u0623\u0645\u0631","broken":"\u062d\u0635\u0644 \u062e\u0637\u0623 \u063a\u064a\u0631 \u0645\u0639\u0631\u0648\u0641"};
/* ]]> */
</script>
<script type='text/javascript' src='wp-includes/js/wp-ajax-response.min0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/theme-my-login/modules/ajax/js/ajax0235.js?ver=4.1.1'></script>
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="../template/xmlrpc.php/index0db0.html?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="../template/wp-includes/wlwmanifest.xml" /> 
<link rel="stylesheet" href="../template/wp-content/themes/sahifa/rtl.css" type="text/css" media="screen" /><meta name="generator" content="WordPress 4.1.1" />
<link href="../template/wp-content/plugins/newsletter/subscription/styles/neutral.css" type="text/css" rel="stylesheet"><link href="../template/wp-content/plugins/newsletter/subscription/styles/widget-neutral.css" type="text/css" rel="stylesheet"><link rel="shortcut icon" href="../template/wp-content/uploads/2015/01/favicon-3.ico" title="Favicon" />	
<!--[if IE]>
<script type="text/javascript">jQuery(document).ready(function (){ jQuery(".menu-item").has("ul").children("a").attr("aria-haspopup", "true");});</script>
<![endif]-->	
<!--[if lt IE 9]>
<script src="http://debonoacademy.co/wp-content/themes/sahifa/js/html5.js"></script>
<script src="http://debonoacademy.co/wp-content/themes/sahifa/js/selectivizr-min.js"></script>
<![endif]-->
<!--[if IE 9]>
<link rel="stylesheet" type="text/css" media="all" href="http://debonoacademy.co/wp-content/themes/sahifa/css/ie9.css" />
<![endif]-->
<!--[if IE 8]>
<link rel="stylesheet" type="text/css" media="all" href="http://debonoacademy.co/wp-content/themes/sahifa/css/ie8.css" />
<![endif]-->
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" media="all" href="http://debonoacademy.co/wp-content/themes/sahifa/css/ie7.css" />
<![endif]-->
<script type='text/javascript'>
	/* <![CDATA[ */
	var tievar = {'go_to' : 'إذهب إلى ...'};
	var tie = {"ajaxurl":"http://debonoacademy.co/wp-admin/admin-ajax.php" , "your_rating":"تقييمك:"};
	/* ]]> */
</script>

<meta name="viewport" content="width=1045" />
	
<style type="text/css" media="screen"> 
::-webkit-scrollbar {width: 8px; height:8px; }

body{
background-color:#0C4173 !important; 
}
	#main-nav,.cat-box-content,#sidebar .widget-container,.post-listing {border-bottom-color: #0C4173;}
	.search-block .search-button,
	#topcontrol,
	#main-nav ul li.current-menu-item a,
	#main-nav ul li.current-menu-item a:hover,
	#main-nav ul li.current-menu-parent a,
	#main-nav ul li.current-menu-parent a:hover,
	#main-nav ul li.current-page-ancestor a,
	#main-nav ul li.current-page-ancestor a:hover,
	.pagination span.current,
	.share-post span.share-text,
	.flex-control-paging li a.flex-active,
	.ei-slider-thumbs li.ei-slider-element,
	.review-percentage .review-item span span,.review-final-score ,
	.woocommerce span.onsale, .woocommerce-page span.onsale ,
	.woocommerce .widget_price_filter .ui-slider .ui-slider-handle, .woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle  {
		background-color:#0C4173 !important;
	}
	::-webkit-scrollbar-thumb{background-color:#0C4173 !important;}
	footer#theme-footer, .top-nav, .top-nav ul li.current-menu-item:after,#main-nav ul li.mega-menu .mega-menu-block, #main-nav ul ul {border-top-color: #0C4173;}
	.search-block:after {border-right-color:#0C4173;}
	#main-nav ul > li.parent-list:hover > a:after{border-color:transparent transparent #0C4173;}

</style> 

    </head>
        <body id="top" class="rtl home blog">
                    <!--<div class="background-cover"></div>-->
                        <!--<div class="header-container">-->
        <header id="theme-header" class="theme-header">
                            <div class="top-nav">
                    <div class="top-continer container">
                                                		<div class="social-icons icon_16">
		<a class="tooldown" title="Rss" href="indexd784.html?feed=rss2" target="_blank"><i class="tieicon-rss"></i></a><a class="tooldown" title="Google+" href="https://plus.google.com/?gpsrc=ogpy0&amp;tab=TX" target="_blank"><i class="tieicon-gplus"></i></a><a class="tooldown" title="Facebook" href="https://www.facebook.com/debono.academy00" target="_blank"><i class="tieicon-facebook"></i></a><a class="tooldown" title="Twitter" href="https://twitter.com/DebonoAcademy" target="_blank"><i class="tieicon-twitter"></i></a><a class="tooldown" title="LinkedIn" href="https://www.linkedin.com/profile/view?id=399434697&amp;trk=nav_responsive_tab_profile_pic" target="_blank"><i class="tieicon-linkedin"></i></a><a class="tooldown" title="instagram" href="http://instagram.com/debonoacademy" target="_blank"><i class="tieicon-instagram"></i></a>	</div>

                        <div class="top-menu"><ul id="menu-top" class="menu"><li id="menu-item-627" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-627"><a href="index6d0d.html?page_id=618">دخول الادارة</a></li>
</ul></div>                        <div class="search-block">
                            <form method="get" id="searchform-header" action="http://debonoacademy.co/">
                                <button class="search-button" type="submit" value="بحث"></button> 
                                <input type="text" id="s" name="s" value="أدخل كلمة البحث ..." onfocus="if (this.value == 'أدخل كلمة البحث ...') {
                                                    this.value = '';
                                                }" onblur="if (this.value == '') {
                                                            this.value = 'أدخل كلمة البحث ...';
                                                        }"  />
                            </form>
                        </div><!-- .search-block /-->
                                                
                                            </div>
                </div><!-- .top-menu /-->
            
            <div class="header-content">
                                    <div class="logo">
                        <h1>                                                                                <a title="اكاديمية ديبونو" href="index.html">
                                <img src="../template/wp-content/uploads/2015/02/depono-logo6-300x90.png" alt="اكاديمية ديبونو" /><strong>اكاديمية ديبونو اكاديمية ديبونو العالمية</strong>
                            </a>
                                                </h1>                    </div><!-- .logo /-->
                                                    <nav class="header-icon-menu-nav">
                    <div class="main-menu header-icon-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d9%84%d9%87%d9%8a%d8%af%d8%b1" class="menu"><li id="menu-item-546" class="vb-47 menu-item menu-item-type-custom menu-item-object-custom menu-item-546"><a href="#">الدخول للمنتديات</a></li>
<li id="menu-item-581" class="media-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-581"><a href="indexdcde.html?page_id=567">البوابة الاعلامية</a></li>
<li id="menu-item-580" class="certi-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-580"><a href="indexd2aa.html?page_id=569">ركـن  الـشهـادات</a></li>
<li id="menu-item-579" class="img-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-579"><a href="index1a11.html?page_id=572">مكتبة الصور</a></li>
<li id="menu-item-578" class="video-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-578"><a href="index5573.html?page_id=571">مكتبة الفيديو</a></li>
<li id="menu-item-577" class="mobile-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-577"><a href="indexe6db.html?page_id=574">تطبيق الجوال</a></li>
<li id="menu-item-556" class="visitors-47 menu-item menu-item-type-post_type menu-item-object-page menu-item-556"><a href="index9cb2.html?page_id=554">سجـل الــــزوار</a></li>
</ul></div>                </nav><!-- .main-nav /-->

                <div class="clear"></div>
            </div>	
                                                      
                

                    </header><!-- #header /-->
        <div class="e3lan-topp container">					
			<a href="#" title="" target="_blank">
				<img src="../template/wp-content/uploads/2015/01/gif2.gif" alt="" />
			</a>
				</div>
        <!--</div>-->
        	
                <nav id="main-nav" class="container">
            <div class="container">
                <div class="main-menu"><ul id="menu-main" class="menu"><li id="menu-item-342" class="menu-item  menu-item-type-custom  menu-item-object-custom  current-menu-item  current_page_item  menu-item-home"><a href="index.html">الرئيسية</a></li>
<li id="menu-item-519" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="indexf72e.html?page_id=512">الاهداف</a></li>
<li id="menu-item-522" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="index7dca.html?page_id=507">عن اكاديمية ديبونو</a></li>
<li id="menu-item-521" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="indexa96a.html?page_id=509">الرؤية</a></li>
<li id="menu-item-520" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="index5b02.html?page_id=511">الرسالة</a></li>
<li id="menu-item-771" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="index9a5c.html?page_id=764">تصميم مواقع للمدربين</a></li>
<li id="menu-item-582" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="index5532.html?page_id=559">ركن الخدمات الالكترونية</a></li>
<li id="menu-item-585" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="indexcfd7.html?page_id=563">طرق الدفع</a></li>
<li id="menu-item-655" class="menu-item  menu-item-type-post_type  menu-item-object-page"><a href="indexf073.html?page_id=565">طرق التواصل معنا</a></li>
</ul></div>                            </div>
        </nav><!-- .main-nav /-->
        <div id="main-content" class="container sidebar-left">


<div class="content">
        <div id="slider-pro-47-shortcode" class="slider-pro">
        <div class="sp-slides">
            
                <div class="sp-slide">
                    <img class="sp-image" src="../template/wp-content/uploads/2015/01/12.jpg"
                         data-src="wp-content/uploads/2015/01/12.jpg"
                         data-retina="wp-content/uploads/2015/01/12.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="index5643.html?p=30">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="../template/wp-content/uploads/2015/01/11.jpg"
                         data-src="wp-content/uploads/2015/01/11.jpg"
                         data-retina="wp-content/uploads/2015/01/11.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="indexdd23.html?p=33">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="../template/wp-content/uploads/2015/01/12.jpg"
                         data-src="wp-content/uploads/2015/01/12.jpg"
                         data-retina="wp-content/uploads/2015/01/12.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="index0d0b.html?p=36">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="../template/wp-content/uploads/2015/01/13.jpg"
                         data-src="wp-content/uploads/2015/01/13.jpg"
                         data-retina="wp-content/uploads/2015/01/13.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="indexba52.html?p=39">أكمل القراءة &raquo;</a>
                    </div>
                </div>
            
                <div class="sp-slide">
                    <img class="sp-image" src="../template/wp-content/uploads/2015/01/10.jpg"
                         data-src="wp-content/uploads/2015/01/10.jpg"
                         data-retina="wp-content/uploads/2015/01/10.jpg"/>
                    <div class="sp-caption">                        <a class="more" href="indexfbd5.html?p=42">أكمل القراءة &raquo;</a>
                    </div>
                </div>
                    </div>
        <div class="sp-thumbnails">
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                            <div class="sp-thumbnail">
                    <div class="sp-thumbnail-image-container">
                    </div>
                    <div class="sp-thumbnail-text">
                        <div class="sp-thumbnail-title">عنوان عنوان عنوان</div>
                        <!--<div class="sp-thumbnail-description"></div>-->
                    </div>
                </div>
                    </div>
    </div>

    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery('#slider-pro-47-shortcode').sliderPro({
                width: 600,
                height: 300,
                orientation: 'vertical',
                loop: false,
                arrows: true,
                buttons: false,
                thumbnailsPosition: 'left',
                thumbnailPointer: true,
                thumbnailWidth: 200,
                thumbnailHeight:72,
                breakpoints: {
                    800: {
                        thumbnailsPosition: 'bottom',
                        thumbnailWidth: 100,
                        thumbnailHeight: 50
                    },
                    500: {
                        thumbnailsPosition: 'bottom',
                        thumbnailWidth: 50,
                        thumbnailHeight: 50
                    }
                }
            });
        });
    </script>

            <div class="tertiary-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/03.jpg"/></a></div>

                <div class="tertiary-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/02.jpg"/></a></div>

                <div class="tertiary-width"><a href="index6fe2.html?p=701" target="_blank"><img src="../template/wp-content/uploads/2015/01/011.jpg"/></a></div>

            <div class="one_half">

        <div class=" home-widget widget-body"><h2 class="home-widget widget-header">سيرفر التسويق الالكتروني</h2>			<div class="textwidget"><p style="margin-top: 5px;">
    <a href="#">

        <img  src="../template/wp-content/uploads/2015/01/sms.jpg" />
    </a>
<p/>
<p>
    <a href="#">
        <img  src="../template/wp-content/uploads/2015/01/e-mail.jpg" />
    </a>
</p>
<p>
    <a href="#">
        <img  src="../template/wp-content/uploads/2015/01/whats.jpg" />
    </a>
</p></div>
		</div>        <div class="full-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/1-1.jpg"/></a></div>

        <style>.rpwe-block ul{
list-style: none !important;
margin-left: 0 !important;
padding-left: 0 !important;
}

.rpwe-block li{
border-bottom: 1px solid #eee;
margin-bottom: 10px;
padding-bottom: 10px;
list-style-type: none;
}

.rpwe-block a{
display: inline !important;
text-decoration: none;
}

.rpwe-block h3{
background: none !important;
clear: none;
margin-bottom: 0 !important;
margin-top: 0 !important;
font-weight: 400;
font-size: 12px !important;
line-height: 1.5em;
}

.rpwe-thumb{
border: 1px solid #eee !important;
box-shadow: none !important;
margin: 2px 10px 2px 0;
padding: 3px !important;
}

.rpwe-summary{
font-size: 12px;
}

.rpwe-time{
color: #bbb;
font-size: 11px;
}

.rpwe-alignleft{
display: inline;
float: left;
}

.rpwe-alignright{
display: inline;
float: right;
}

.rpwe-aligncenter{
display: block;
margin-left: auto;
margin-right: auto;
}

.rpwe-clearfix:before,
.rpwe-clearfix:after{
content: "";
display: table !important;
}

.rpwe-clearfix:after{
clear: both;
}

.rpwe-clearfix{
zoom: 1;
}
</style><div class=" home-widget widget-body"><h2 class="home-widget widget-header">مركز تحميل دي بونو</h2><div  class="rpwe-block "><ul class="rpwe-ul"><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index94b0.html?p=48"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="../template/wp-content/uploads/2014/12/10941698_1555959114668696_747968466_n-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index94b0.html?p=48" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index5e74.html?p=45"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="../template/wp-content/uploads/2015/01/4-3-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index5e74.html?p=45" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="indexfbd5.html?p=42"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="../template/wp-content/uploads/2015/01/10-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="indexfbd5.html?p=42" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li></ul></div><!-- Generated by http://wordpress.org/plugins/recent-posts-widget-extended/ --></div>    </div>
    <div class="one_half last">
        <div class="  home-widget widget-body"><h2 class="home-widget widget-header">خدمات اكاديمية دي بونو</h2>			<div class="textwidget"><p style="margin-top: 5px;">
    <a href="indexac94.html?cat=42">

        <img  src="../template/wp-content/uploads/2015/01/5-1.jpg" />
    </a>
<p/>
<p>
    <a href="indexffca.html?cat=41">
        <img  src="../template/wp-content/uploads/2015/01/5-2.jpg" />
    </a>
</p>
<p>
    <a href="index51fa.html?cat=40">
        <img  src="../template/wp-content/uploads/2015/01/5-3.jpg" />
    </a>
</p></div>
		</div>        <div class="full-width"><a href="indexe0a3.html?page_id=660" target="_blank"><img src="../template/wp-content/uploads/2015/01/motadarbeen.jpg"/></a></div>

        <style>.rpwe-block ul{
list-style: none !important;
margin-left: 0 !important;
padding-left: 0 !important;
}

.rpwe-block li{
border-bottom: 1px solid #eee;
margin-bottom: 10px;
padding-bottom: 10px;
list-style-type: none;
}

.rpwe-block a{
display: inline !important;
text-decoration: none;
}

.rpwe-block h3{
background: none !important;
clear: none;
margin-bottom: 0 !important;
margin-top: 0 !important;
font-weight: 400;
font-size: 12px !important;
line-height: 1.5em;
}

.rpwe-thumb{
border: 1px solid #eee !important;
box-shadow: none !important;
margin: 2px 10px 2px 0;
padding: 3px !important;
}

.rpwe-summary{
font-size: 12px;
}

.rpwe-time{
color: #bbb;
font-size: 11px;
}

.rpwe-alignleft{
display: inline;
float: left;
}

.rpwe-alignright{
display: inline;
float: right;
}

.rpwe-aligncenter{
display: block;
margin-left: auto;
margin-right: auto;
}

.rpwe-clearfix:before,
.rpwe-clearfix:after{
content: "";
display: table !important;
}

.rpwe-clearfix:after{
clear: both;
}

.rpwe-clearfix{
zoom: 1;
}
</style><div class="  home-widget widget-body"><h2 class="home-widget widget-header">جديد اخبار دي بونو</h2><div  class="rpwe-block "><ul class="rpwe-ul"><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index94b0.html?p=48"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="../template/wp-content/uploads/2014/12/10941698_1555959114668696_747968466_n-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index94b0.html?p=48" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="index5e74.html?p=45"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="../template/wp-content/uploads/2015/01/4-3-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="index5e74.html?p=45" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li><li class="rpwe-li rpwe-clearfix"><a class="rpwe-img" href="indexfbd5.html?p=42"  rel="bookmark"><img class="rpwe-alignright rpwe-thumb" src="../template/wp-content/uploads/2015/01/10-100x55.jpg" alt="عنوان عنوان عنوان"></a><h3 class="rpwe-title"><a href="indexfbd5.html?p=42" title="Permalink to عنوان عنوان عنوان" rel="bookmark">عنوان عنوان عنوان</a></h3></li></ul></div><!-- Generated by http://wordpress.org/plugins/recent-posts-widget-extended/ --></div>
    </div>
    
        <div style="margin-top: 38px; float: right;" class="last">
       
                <div class="full-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/mobile.jpg"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/1-2.gif"/></a></div>

                <div class="full-width"><a href="http://3agroupeg.com/en/index.html" target="_blank"><img src="../template/wp-content/uploads/2015/01/234.jpg"/></a></div>

        
    </div>
    		
</div><!-- .content /-->

<aside id="sidebar">
        <div class="full-width"><a href="index0e0c.html?post_type=training_packages" target="_blank"><img src="../template/wp-content/uploads/2015/01/05.jpg"/></a></div>

                <div class="full-width"><a href="index76ba.html?post_type=training_centers" target="_blank"><img src="../template/wp-content/uploads/2015/01/06.jpg"/></a></div>

                <div class="full-width"><a href="indexd083.html?page_id=588" target="_blank"><img src="../template/wp-content/uploads/2015/01/20.jpg"/></a></div>

                <div class="full-width"><a href="index8568.html?page_id=587" target="_blank"><img src="../template/wp-content/uploads/2015/01/04.jpg"/></a></div>

                <div class="full-width"><a href="index6336.html?post_type=course_amin" target="_blank"><img src="../template/wp-content/uploads/2015/01/01.jpg"/></a></div>

                <div class="full-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/0021.jpg"/></a></div>

        <div id="youtube_responsive-2" class="widget widget_youtube_responsive"><div class="widget-top"><h4>ارشيف الفيديو</h4><div class="stripe-line"></div></div>
						<div class="widget-container"><iframe id='1' class='StefanoAI-youtube-responsive ' width='160' height='90' src='http://www.youtube.com/embed/nvtolFFXTwc?&amp;autohide=2&amp;hl=ar&amp;color=red&amp;controls=1&amp;disablekb=1&amp;fs=1&amp;iv_load_policy=3&amp;loop=0&amp;modestbranding=0&amp;rel=0&amp;theme=dark&amp;vq=default' frameborder='0' allowfullscreen="true" style=''></iframe></div></div><!-- .widget /-->        <div class="full-width"><a href="#" target="_blank"><img src="../template/wp-content/uploads/2015/01/gif1.gif"/></a></div>

        <div id="newsletterwidget-2" class="widget widget_newsletterwidget"><div class="widget-top"><h4>القائمة البريدية</h4><div class="stripe-line"></div></div>
						<div class="widget-container">اشترك في القائمة البريدية ليصلك كل جديد

<script type="text/javascript">
//<![CDATA[
if (typeof newsletter_check !== "function") {
window.newsletter_check = function (f) {
    var re = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-]{1,})+\.)+([a-zA-Z0-9]{2,})+$/;
    if (!re.test(f.elements["ne"].value)) {
        alert("هذا البريد غير صالح");
        return false;
    }
    if (f.elements["nn"] && (f.elements["nn"].value == "" || f.elements["nn"].value == f.elements["nn"].defaultValue)) {
        alert("هذا الاسم غير صالح ");
        return false;
    }
    if (f.elements["ny"] && !f.elements["ny"].checked) {
        alert("You must accept the privacy statement");
        return false;
    }
    return true;
}
}
//]]>
</script>

<div class="newsletter newsletter-widget">

<script type="text/javascript">
//<![CDATA[
if (typeof newsletter_check !== "function") {
window.newsletter_check = function (f) {
    var re = /^([a-zA-Z0-9_\.\-\+])+\@(([a-zA-Z0-9\-]{1,})+\.)+([a-zA-Z0-9]{2,})+$/;
    if (!re.test(f.elements["ne"].value)) {
        alert("هذا البريد غير صالح");
        return false;
    }
    if (f.elements["nn"] && (f.elements["nn"].value == "" || f.elements["nn"].value == f.elements["nn"].defaultValue)) {
        alert("هذا الاسم غير صالح ");
        return false;
    }
    if (f.elements["ny"] && !f.elements["ny"].checked) {
        alert("You must accept the privacy statement");
        return false;
    }
    return true;
}
}
//]]>
</script>

<form action="http://debonoacademy.co/wp-content/plugins/newsletter/do/subscribe.php" onsubmit="return newsletter_check(this)" method="post"><input type="hidden" name="nr" value="widget"/><p><input class="newsletter-firstname" type="text" name="nn" value="الاسم " onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-email" type="email" required name="ne" value="البريد الالكتروني" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-1" type="text" name="np1" value="الجوال" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-2" type="text" name="np2" value="جهة العمل" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-3" type="text" name="np3" value="الدولة" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-4" type="text" name="np4" value="المنطقة" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-profile newsletter-profile-5" type="text" name="np5" value="الموقع الالكتروني" onclick="if (this.defaultValue==this.value) this.value=''" onblur="if (this.value=='') this.value=this.defaultValue"/></p><p><input class="newsletter-submit" type="submit" value="اشترك"/></p></form></div></div></div><!-- .widget /--><div id="flag-counter-widget-2" class="widget flagcounter"><div class="widget-top"><h4>زوارانا</h4><div class="stripe-line"></div></div>
						<div class="widget-container"><!--flags.es Start-->
<script type="text/javascript">
 <!--//
 ami_v = 500; // no. of visitors to display, max. no.: 500.
 ami_l = "000000"; // link colour, any hexadezimal colour code.
 ami_t = "000000"; // text colour, any hexadezimal colour code.
 ami_c = "FFFFFF"; // background colour, any hexadezimal colour code.
 ami_b = "000000"; // border colour, any hexadezimal colour code.
 ami_s = 13; // font size in pixels.
 ami_w = 285; // counter width in pixels.
 ami_h = 128; // counter height in pixels.
 ami_sc = 1; // show the total visitors count, on = 1 - off = 2.
 ami_to = 30; // time in seconds, for how long an allready existing ip wont be logged again. set to 1 for an hit count.
 ami_sm = "c"; // show last Visitors or best Countries, v = visitors - c = countries.
 ami_d = "2"; // format the display in columns, no. of columns.
 //-->
</script>
<script type="text/javascript" src="../template/../www.flags.es/geoip/amiip.js"></script>
<br><a href="http://www.flags.es/" target="_blank"><font size=1>flags.es</font></a>
<!--flags.es End-->
</div></div><!-- .widget /--></aside><div class="clear"></div>
<nav  class="container-last-menu">
    <div class="last-wrap">
        <div class="main-menu"><ul id="menu-%d9%82%d8%a7%d8%a6%d9%85%d8%a9-%d8%a7%d8%b9%d9%84%d9%89-%d8%a7%d9%84%d9%81%d9%88%d8%aa%d8%b1" class="menu"><li id="menu-item-464" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-465" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-466" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-467" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-468" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
<li id="menu-item-469" class="menu-item  menu-item-type-custom  menu-item-object-custom"><a href="#">عنوان رئيسي</a></li>
</ul></div>    </div>
</nav><!-- .main-nav /-->
<div class="clear"></div>
</div><!-- .container /-->

<footer id="theme-footer">
	<div id="footer-widget-area" class="wide-narrow-2c">

	
	

	
		
	</div><!-- #footer-widget-area -->
	<div class="clear"></div>
</footer><!-- .Footer /-->
				
<div class="clear"></div>
<div class="footer-bottom">
    <div class="container">
        <div class="alignright">
            الموقع من تصميم وبرمجة و تطوير مجموعة ثري ايه الدولية         </div>

        <div class="alignleft">
            جميع الحقوق محفوظة لاكاديمية ديبونو العالمية        </div>
        <div class="clear"></div>
    </div><!-- .Container -->
</div><!-- .Footer bottom -->
<div id="fb-root"></div>
<link rel='stylesheet' id='example-css-css'  href='wp-content/plugins/slider-47/inc/examples/css/examples0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='slider-pro-css-47-css'  href='wp-content/plugins/slider-47/inc/dist/css/slider-pro0235.css?ver=4.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='open-sans-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A300italic%2C400italic%2C600italic%2C300%2C400%2C600&amp;subset=latin%2Clatin-ext&amp;ver=4.1.1' type='text/css' media='all' />
<script type='text/javascript' src='wp-content/plugins/contact-form-7/includes/js/jquery.form.mind03d.js?ver=3.51.0-2014.06.20'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var _wpcf7 = {"loaderUrl":"http:\/\/debonoacademy.co\/wp-content\/plugins\/contact-form-7\/images\/ajax-loader.gif","sending":"\u062c\u0627\u0631\u064a \u0627\u0644\u0625\u0631\u0633\u0627\u0644 ..."};
/* ]]> */
</script>
<script type='text/javascript' src='wp-content/plugins/contact-form-7/includes/js/scripts2f54.js?ver=4.1'></script>
<script type='text/javascript' src='wp-content/themes/sahifa/js/tie-scripts0235.js?ver=4.1.1'></script>
<script type='text/javascript' src='wp-content/plugins/slider-47/inc/dist/js/jquery.sliderPro.min0235.js?ver=4.1.1'></script>
<script type="text/javascript">function AI_responsive_widget() {
                        jQuery('iframe.StefanoAI-youtube-responsive').each(function() {
                            var width = jQuery(this).parent().innerWidth();
                            var maxwidth = jQuery(this).css('max-width').replace(/px/, '');
                            var pl = parseInt(jQuery(this).parent().css('padding-left').replace(/px/, ''));
                            var pr = parseInt(jQuery(this).parent().css('padding-right').replace(/px/, ''));
                            width = width - pl - pr;
                            if (maxwidth < width) {
                                width = maxwidth;
                            }
                            jQuery(this).css('width', width + "px");
                            jQuery(this).css('height', width / (16 / 9) + "px");
                        });
                    }
                    if (typeof jQuery !== 'undefined') {
                        jQuery(document).ready(function() {
                            AI_responsive_widget();
                        });
                        jQuery(window).resize(function() {
                            AI_responsive_widget();
                        });
                    }</script></body>

<!-- Mirrored from debonoacademy.co/ by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 10 Mar 2015 18:28:05 GMT -->
</html>