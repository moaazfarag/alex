<?php if(!class_exists('raintpl')){exit;}?>

            <!--Start Admin Panal MAin Content Right Block-->
            <div class="main_container col-lg-9 col-md-8 col-sm-9 col-xs- pull-left">
                <div class="row main_container_head">
                    <h4><span class="glyphicon glyphicon-user"></span>أعضاء الموقع </h4>
                </div>

                <div class="row control_panal_body">
                    <!--Start Admin Panal Section Description-->
                    <p class="page_desc">يمكنك إضافة اعضاء جدد مباشرة الي موقعك من الحقول أدناه</p>
                    <!--End Admin Panal Section Description-->


                    <div class="alert alert-success h5" role="alert"><?php echo $message;?></div>
                    
                    
                </div>
            </div>
            <!--Start Admin Panal MAin Content Right Block-->
        </div>
        <!--End Admin Panal Main Body-->


<?php $tpl = new RainTPL;$tpl_dir_temp = self::$tpl_dir;$tpl->assign( $this->var );$tpl->draw( dirname("footer-admin") . ( substr("footer-admin",-1,1) != "/" ? "/" : "" ) . basename("footer-admin") );?>