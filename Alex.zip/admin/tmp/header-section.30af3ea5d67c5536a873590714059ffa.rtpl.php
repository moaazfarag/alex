<?php if(!class_exists('raintpl')){exit;}?>
<!--header end-->
<!--sidebar start-->
<aside dir="rtl">
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li>
                <a class="active kufi font10" href="index.php">
                    <i class="icon-dashboard "></i>
                    <span>الرئيسية</span>
                </a>
            </li>
            

            <li class="sub-menu">
                <a href="javascript:;" >
                    <i ></i>
                    <span class="kufi font10"> الحقائب التدريبيه </span>
                </a>
                <ul class="sub kufi font10" >
                    <li><a style="margin-right : 15px;"  href="trainingPackages.php">جميع الحقائب التدريبية</a></li>
                    <li><a style="margin-right : 15px;" href="#">اضف حقيبة تدريبية</a></li>
                </ul>
            </li>
            
            <li class="sub-menu">
                <a href="javascript:;" >
                    <i class="icon-user"></i>
                    <span>Users</span>
                </a>
                <ul class="sub">
                    <li><a  href="users.php">All users</a></li>
                    <li><a  href="addUser.php">Add users</a></li>
                </ul>
            </li>
            
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->





